// Current selected route/area
let currentRoute = 'all';

// Define routes and their associated roads/intersections
const routeData = {
    all: {
        name: 'All Areas',
        intersections: ['I1', 'I2', 'I3', 'I4', 'I5'],
        roads: ['R001', 'R002', 'R003', 'R004', 'R005', 'R006', 'R007', 'R008', 'R009', 'R010']
    },
    downtown: {
        name: 'Downtown Business District',
        intersections: ['I1', 'I5'],
        roads: ['R001', 'R002', 'R005', 'R009'],
        description: 'High-density commercial area with peak morning and evening traffic'
    },
    highway: {
        name: 'Highway 101 Corridor',
        intersections: ['I2', 'I3'],
        roads: ['R003', 'R004', 'R006', 'R007'],
        description: 'Major highway connecting suburbs to city center'
    },
    residential: {
        name: 'Residential Neighborhoods',
        intersections: ['I4', 'I5'],
        roads: ['R005', 'R006', 'R008'],
        description: 'Residential zones with school and shopping traffic'
    },
    industrial: {
        name: 'Industrial & Warehouse District',
        intersections: ['I3', 'I4'],
        roads: ['R004', 'R007', 'R008', 'R010'],
        description: 'Heavy truck traffic and freight routes'
    },
    airport: {
        name: 'Airport Access Route',
        intersections: ['I2', 'I3', 'I5'],
        roads: ['R003', 'R004', 'R006', 'R007'],
        description: 'Direct routes to city airport with priority for airport shuttles'
    }
};

// Simulated data with realistic intersection management
let trafficData = {
    // Major intersections where 3-4 roads meet
    intersections: [
        { id: 'I1', name: 'Downtown Center', x: 200, y: 250, roads: ['R001', 'R002', 'R005', 'R009'], type: '4-way' },
        { id: 'I2', name: 'North Junction', x: 400, y: 150, roads: ['R002', 'R003', 'R006'], type: '3-way' },
        { id: 'I3', name: 'East Plaza', x: 600, y: 250, roads: ['R003', 'R004', 'R007', 'R010'], type: '4-way' },
        { id: 'I4', name: 'South Hub', x: 400, y: 350, roads: ['R005', 'R006', 'R008'], type: '3-way' },
        { id: 'I5', name: 'Central Square', x: 400, y: 250, roads: ['R001', 'R004', 'R007', 'R008'], type: '4-way' }
    ],
    
    roads: [
        // Horizontal Roads (East-West)
        { id: 'R001', name: 'Main Street (W-E)', vehicles: 120, capacity: 150, congestion: 'HIGH', avgSpeed: 52, utilization: 80, 
          from: 'I1', to: 'I5', intersections: ['I1', 'I5'], direction: 'horizontal' },
        { id: 'R002', name: 'North Avenue (W-E)', vehicles: 95, capacity: 180, congestion: 'MODERATE', avgSpeed: 56, utilization: 53,
          from: 'I1', to: 'I2', intersections: ['I1', 'I2'], direction: 'horizontal' },
        { id: 'R003', name: 'Northeast Road', vehicles: 65, capacity: 120, congestion: 'MODERATE', avgSpeed: 48, utilization: 54,
          from: 'I2', to: 'I3', intersections: ['I2', 'I3'], direction: 'horizontal' },
        { id: 'R004', name: 'East Boulevard', vehicles: 180, capacity: 200, congestion: 'SEVERE', avgSpeed: 20, utilization: 90,
          from: 'I5', to: 'I3', intersections: ['I5', 'I3'], direction: 'horizontal' },
        
        // Vertical Roads (North-South)
        { id: 'R005', name: 'West Highway (N-S)', vehicles: 85, capacity: 140, congestion: 'MODERATE', avgSpeed: 45, utilization: 61,
          from: 'I1', to: 'I4', intersections: ['I1', 'I4'], direction: 'vertical' },
        { id: 'R006', name: 'Central Street (N-S)', vehicles: 140, capacity: 160, congestion: 'HIGH', avgSpeed: 35, utilization: 88,
          from: 'I2', to: 'I4', intersections: ['I2', 'I5', 'I4'], direction: 'vertical' },
        { id: 'R007', name: 'East Parkway (N-S)', vehicles: 75, capacity: 130, congestion: 'MODERATE', avgSpeed: 41, utilization: 58,
          from: 'I3', to: 'I5', intersections: ['I3', 'I5'], direction: 'vertical' },
        { id: 'R008', name: 'South Express (N-S)', vehicles: 50, capacity: 120, congestion: 'LOW', avgSpeed: 65, utilization: 42,
          from: 'I5', to: 'I4', intersections: ['I5', 'I4'], direction: 'vertical' },
        
        // Additional connecting roads
        { id: 'R009', name: 'Downtown Loop', vehicles: 110, capacity: 140, congestion: 'HIGH', avgSpeed: 38, utilization: 79,
          from: 'I1', to: 'I1', intersections: ['I1'], direction: 'circular' },
        { id: 'R010', name: 'Harbor Drive', vehicles: 30, capacity: 100, congestion: 'LOW', avgSpeed: 50, utilization: 30,
          from: 'I3', to: 'I3', intersections: ['I3'], direction: 'service' }
    ],
    // Traffic signals at each intersection (managing 3-4 roads each)
    signals: [
        { location: 'I1-Downtown', intersection: 'I1', name: 'Downtown Center', state: 'GREEN', greenDuration: 40, redDuration: 30, 
          managedRoads: 4, priority: 'high' },
        { location: 'I2-North', intersection: 'I2', name: 'North Junction', state: 'RED', greenDuration: 30, redDuration: 35,
          managedRoads: 3, priority: 'medium' },
        { location: 'I3-East', intersection: 'I3', name: 'East Plaza', state: 'YELLOW', greenDuration: 35, redDuration: 30,
          managedRoads: 4, priority: 'high' },
        { location: 'I4-South', intersection: 'I4', name: 'South Hub', state: 'GREEN', greenDuration: 28, redDuration: 32,
          managedRoads: 3, priority: 'medium' },
        { location: 'I5-Central', intersection: 'I5', name: 'Central Square', state: 'RED', greenDuration: 45, redDuration: 25,
          managedRoads: 4, priority: 'critical' }
    ],
    vehicles: [
        { id: 'V001', type: 'CAR', location: 'S1-Downtown', speed: 52, priority: 1 },
        { id: 'V002', type: 'CAR', location: 'S2-North', speed: 20, priority: 1 },
        { id: 'V003', type: 'BUS', location: 'S3-South', speed: 56, priority: 3 },
        { id: 'V004', type: 'CAR', location: 'S4-East', speed: 48, priority: 1 },
        { id: 'V005', type: 'TRUCK', location: 'S5-West', speed: 45, priority: 2 },
        { id: 'V006', type: 'CAR', location: 'S6-Central', speed: 35, priority: 1 },
        { id: 'V007', type: 'MOTORCYCLE', location: 'S7-Park', speed: 50, priority: 1 },
        { id: 'V008', type: 'BUS', location: 'S8-Harbor', speed: 41, priority: 3 },
        { id: 'V009', type: 'EMERGENCY', location: 'S1-Downtown', speed: 70, priority: 5 },
        { id: 'V010', type: 'CAR', location: 'S2-North', speed: 20, priority: 1 },
        { id: 'V011', type: 'BUS', location: 'S3-South', speed: 55, priority: 3 },
        { id: 'V012', type: 'CAR', location: 'S4-East', speed: 47, priority: 1 },
        { id: 'V013', type: 'MOTORCYCLE', location: 'S5-West', speed: 60, priority: 1 },
        { id: 'V014', type: 'TRUCK', location: 'S6-Central', speed: 30, priority: 2 },
        { id: 'V015', type: 'EMERGENCY', location: 'S7-Park', speed: 75, priority: 5 }
    ]
};

// Initialize the dashboard
function initDashboard() {
    // Check authentication and display user info
    displayUserInfo();
    
    updateTrafficTable();
    updateSignalsGrid();
    updateVehicles();
    updateAlerts();
    drawTrafficMap();
    updateStats();
    updateLastUpdate();
    
    // Start live updates
    setInterval(() => {
        simulateTrafficChanges();
        refreshData();
    }, 3000);
    
    // Update signals
    setInterval(updateSignalStates, 2000);
}

// Update traffic table
function updateTrafficTable() {
    const tbody = document.getElementById('trafficTableBody');
    tbody.innerHTML = '';
    
    trafficData.roads.forEach(road => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><strong>${road.name}</strong></td>
            <td>${road.vehicles}/${road.capacity}</td>
            <td><span class="congestion-badge congestion-${road.congestion}">${road.congestion}</span></td>
            <td>${road.avgSpeed} km/h</td>
            <td>
                <div style="width: 100%; background: #e5e7eb; border-radius: 10px; height: 8px;">
                    <div style="width: ${road.utilization}%; background: ${getUtilizationColor(road.utilization)}; 
                         height: 100%; border-radius: 10px; transition: width 0.5s;"></div>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Update signals grid with intersection management info
function updateSignalsGrid() {
    const grid = document.getElementById('signalsGrid');
    grid.innerHTML = '';
    
    trafficData.signals.forEach(signal => {
        const card = document.createElement('div');
        card.className = 'signal-card';
        
        const priorityColor = signal.priority === 'critical' ? '#ef4444' : 
                            signal.priority === 'high' ? '#f97316' : '#fbbf24';
        
        card.innerHTML = `
            <div class="signal-header">
                <div>
                    <span class="signal-name">${signal.name}</span>
                    <div style="font-size: 0.75rem; color: #6b7280; margin-top: 2px;">
                        ${signal.managedRoads}-way intersection
                    </div>
                </div>
                <div class="signal-light signal-${signal.state}"></div>
            </div>
            <div class="signal-timing">
                🟢 ${signal.greenDuration}s | 🔴 ${signal.redDuration}s
            </div>
            <div style="margin-top: 8px; padding: 4px 8px; background: ${priorityColor}20; 
                        border-left: 3px solid ${priorityColor}; border-radius: 4px; font-size: 0.75rem;">
                Priority: <strong style="text-transform: uppercase;">${signal.priority}</strong>
            </div>
        `;
        grid.appendChild(card);
    });
}

// Update vehicles list
function updateVehicles() {
    const container = document.getElementById('vehiclesContainer');
    container.innerHTML = '';
    
    trafficData.vehicles.forEach(vehicle => {
        const item = document.createElement('div');
        item.className = 'vehicle-item';
        item.innerHTML = `
            <i class="fas ${getVehicleIcon(vehicle.type)} vehicle-icon vehicle-${vehicle.type}"></i>
            <div class="vehicle-info">
                <div class="vehicle-id">${vehicle.id}</div>
                <div class="vehicle-details">${vehicle.type} • ${vehicle.location} • ${vehicle.speed} km/h</div>
            </div>
            ${vehicle.type === 'EMERGENCY' ? '<span style="color: #ef4444; font-weight: bold;">⚡ Priority</span>' : ''}
        `;
        container.appendChild(item);
    });
}

// Update congestion alerts
function updateAlerts() {
    const container = document.getElementById('alertsContainer');
    container.innerHTML = '';
    
    const congestedRoads = trafficData.roads.filter(r => r.congestion === 'HIGH' || r.congestion === 'SEVERE');
    
    if (congestedRoads.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #10b981; padding: 20px;">✓ All roads clear</p>';
        return;
    }
    
    congestedRoads.forEach(road => {
        const alert = document.createElement('div');
        alert.className = `alert alert-${road.congestion === 'SEVERE' ? 'danger' : 'warning'}`;
        alert.innerHTML = `
            <div class="alert-title">⚠️ ${road.congestion} Congestion</div>
            <div>${road.name} - ${road.utilization}% capacity</div>
            <div style="font-size: 0.85rem; margin-top: 5px;">
                ${road.congestion === 'SEVERE' ? 
                    'Consider alternate routes. Expect significant delays.' : 
                    'Heavy traffic detected. Plan for moderate delays.'}
            </div>
        `;
        container.appendChild(alert);
    });
}

// Select route/area
function selectRoute(routeId) {
    currentRoute = routeId;
    
    // Update active button
    document.querySelectorAll('.btn-route').forEach(btn => btn.classList.remove('active'));
    event.target.closest('.btn-route').classList.add('active');
    
    // Update map title
    const titleEl = document.getElementById('mapTitle');
    if (titleEl) {
        titleEl.textContent = `Traffic Network Map - ${routeData[routeId].name}`;
    }
    
    // Filter and update all displays
    drawTrafficMap();
    updateSignalsGrid();
    updateTrafficTable();
    updateStats();
    updateAlerts();
    
    // Show notification
    showNotification(`Viewing: ${routeData[routeId].name}`, 'info');
    
    // Show route description if available
    if (routeData[routeId].description) {
        setTimeout(() => {
            showNotification(routeData[routeId].description, 'info');
        }, 1000);
    }
}

// Get filtered data based on selected route
function getFilteredData() {
    if (currentRoute === 'all') {
        return trafficData;
    }
    
    const route = routeData[currentRoute];
    return {
        intersections: trafficData.intersections.filter(i => route.intersections.includes(i.id)),
        roads: trafficData.roads.filter(r => route.roads.includes(r.id)),
        signals: trafficData.signals.filter(s => route.intersections.includes(s.intersection)),
        vehicles: trafficData.vehicles
    };
}

// Draw realistic traffic map with intersections
function drawTrafficMap() {
    const svg = document.getElementById('trafficMap');
    svg.innerHTML = '';
    
    // Get filtered data for current route
    const filteredData = getFilteredData();
    
    // Create a grid with proper spacing
    const intersectionMap = {
        'I1': { x: 200, y: 250 },  // Downtown Center (4-way)
        'I2': { x: 400, y: 150 },  // North Junction (3-way)
        'I3': { x: 600, y: 250 },  // East Plaza (4-way)
        'I4': { x: 400, y: 350 },  // South Hub (3-way)
        'I5': { x: 400, y: 250 }   // Central Square (4-way)
    };
    
    // Draw roads connecting intersections (only show roads in current route)
    const roadConnections = [
        // Horizontal roads
        { from: 'I1', to: 'I5', roadId: 'R001', label: 'Main St' },
        { from: 'I1', to: 'I2', roadId: 'R002', label: 'North Ave' },
        { from: 'I2', to: 'I3', roadId: 'R003', label: 'NE Road' },
        { from: 'I5', to: 'I3', roadId: 'R004', label: 'East Blvd' },
        
        // Vertical roads
        { from: 'I1', to: 'I4', roadId: 'R005', label: 'West Hwy' },
        { from: 'I2', to: 'I5', roadId: 'R006', label: 'Central St' },
        { from: 'I5', to: 'I4', roadId: 'R008', label: 'South Exp' },
        { from: 'I3', to: 'I5', roadId: 'R007', label: 'East Pkwy' }
    ];
    
    // Draw roads
    roadConnections.forEach(conn => {
        const roadData = trafficData.roads.find(r => r.id === conn.roadId);
        if (!roadData) return;
        
        const fromPos = intersectionMap[conn.from];
        const toPos = intersectionMap[conn.to];
        
        // Draw road line
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', fromPos.x);
        line.setAttribute('y1', fromPos.y);
        line.setAttribute('x2', toPos.x);
        line.setAttribute('y2', toPos.y);
        line.setAttribute('class', `road-line ${roadData.congestion === 'SEVERE' || roadData.congestion === 'HIGH' ? 'congested' : ''}`);
        line.setAttribute('stroke', getCongestionColor(roadData.congestion));
        line.setAttribute('stroke-width', roadData.congestion === 'SEVERE' ? '10' : '6');
        svg.appendChild(line);
        
        // Add road label with congestion indicator
        const midX = (fromPos.x + toPos.x) / 2;
        const midY = (fromPos.y + toPos.y) / 2;
        
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', midX);
        text.setAttribute('y', midY - 12);
        text.setAttribute('class', 'road-label');
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('fill', '#1f2937');
        text.setAttribute('font-weight', 'bold');
        text.textContent = conn.label;
        svg.appendChild(text);
        
        // Add vehicle count indicator
        const countText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        countText.setAttribute('x', midX);
        countText.setAttribute('y', midY + 5);
        countText.setAttribute('text-anchor', 'middle');
        countText.setAttribute('font-size', '10');
        countText.setAttribute('fill', '#6b7280');
        countText.textContent = `🚗 ${roadData.vehicles}`;
        svg.appendChild(countText);
    });
    
    // Draw intersections with signal indicators (only show intersections in current route)
    filteredData.intersections.forEach(intersection => {
        const pos = intersectionMap[intersection.id];
        const signal = filteredData.signals.find(s => s.intersection === intersection.id);
        
        // Draw intersection circle
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', pos.x);
        circle.setAttribute('cy', pos.y);
        circle.setAttribute('r', 25);
        circle.setAttribute('fill', signal ? getSignalColor(signal.state) : '#94a3b8');
        circle.setAttribute('class', 'signal-indicator');
        circle.setAttribute('stroke', '#1f2937');
        circle.setAttribute('stroke-width', '3');
        svg.appendChild(circle);
        
        // Add intersection name
        const nameText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        nameText.setAttribute('x', pos.x);
        nameText.setAttribute('y', pos.y - 40);
        nameText.setAttribute('text-anchor', 'middle');
        nameText.setAttribute('font-size', '12');
        nameText.setAttribute('font-weight', 'bold');
        nameText.setAttribute('fill', '#1f2937');
        nameText.textContent = intersection.name;
        svg.appendChild(nameText);
        
        // Add intersection type (3-way or 4-way)
        const typeText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        typeText.setAttribute('x', pos.x);
        typeText.setAttribute('y', pos.y + 45);
        typeText.setAttribute('text-anchor', 'middle');
        typeText.setAttribute('font-size', '10');
        typeText.setAttribute('fill', '#6b7280');
        typeText.textContent = `${intersection.type} junction`;
        svg.appendChild(typeText);
        
        // Add signal state indicator inside circle
        const stateText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        stateText.setAttribute('x', pos.x);
        stateText.setAttribute('y', pos.y + 5);
        stateText.setAttribute('text-anchor', 'middle');
        stateText.setAttribute('font-size', '10');
        stateText.setAttribute('font-weight', 'bold');
        stateText.setAttribute('fill', 'white');
        stateText.textContent = signal ? signal.state[0] : '?';
        svg.appendChild(stateText);
    });
    
    // Add legend
    const legendY = 450;
    const legendItems = [
        { color: '#10b981', text: 'Low Traffic' },
        { color: '#fbbf24', text: 'Moderate' },
        { color: '#f97316', text: 'High' },
        { color: '#ef4444', text: 'Severe' }
    ];
    
    legendItems.forEach((item, i) => {
        const x = 100 + (i * 150);
        const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        rect.setAttribute('x', x);
        rect.setAttribute('y', legendY);
        rect.setAttribute('width', 30);
        rect.setAttribute('height', 10);
        rect.setAttribute('fill', item.color);
        svg.appendChild(rect);
        
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', x + 35);
        text.setAttribute('y', legendY + 9);
        text.setAttribute('font-size', '11');
        text.setAttribute('fill', '#374151');
        text.textContent = item.text;
        svg.appendChild(text);
    });
}

// Helper functions
function getUtilizationColor(utilization) {
    if (utilization < 30) return '#10b981';
    if (utilization < 60) return '#fbbf24';
    if (utilization < 85) return '#f97316';
    return '#ef4444';
}

function getCongestionColor(congestion) {
    const colors = {
        'LOW': '#10b981',
        'MODERATE': '#fbbf24',
        'HIGH': '#f97316',
        'SEVERE': '#ef4444'
    };
    return colors[congestion] || '#94a3b8';
}

function getSignalColor(state) {
    const colors = {
        'RED': '#ef4444',
        'YELLOW': '#fbbf24',
        'GREEN': '#10b981'
    };
    return colors[state] || '#94a3b8';
}

function getVehicleIcon(type) {
    const icons = {
        'CAR': 'fa-car',
        'BUS': 'fa-bus',
        'TRUCK': 'fa-truck',
        'MOTORCYCLE': 'fa-motorcycle',
        'EMERGENCY': 'fa-ambulance'
    };
    return icons[type] || 'fa-car';
}

// Simulate traffic changes
function simulateTrafficChanges() {
    trafficData.roads.forEach(road => {
        const change = Math.floor(Math.random() * 11) - 5;
        road.vehicles = Math.max(0, Math.min(road.capacity, road.vehicles + change));
        road.utilization = Math.round((road.vehicles / road.capacity) * 100);
        
        // Update congestion
        if (road.utilization < 30) road.congestion = 'LOW';
        else if (road.utilization < 60) road.congestion = 'MODERATE';
        else if (road.utilization < 85) road.congestion = 'HIGH';
        else road.congestion = 'SEVERE';
        
        // Update speed
        road.avgSpeed = Math.round(road.avgSpeed * (1 - road.utilization / 200)) + Math.random() * 5;
    });
}

// Update signal states
function updateSignalStates() {
    trafficData.signals.forEach(signal => {
        const states = ['RED', 'YELLOW', 'GREEN'];
        const currentIndex = states.indexOf(signal.state);
        signal.state = states[(currentIndex + 1) % states.length];
    });
    updateSignalsGrid();
    drawTrafficMap();
}

// Update statistics
function updateStats() {
    const filteredData = getFilteredData();
    const route = routeData[currentRoute];
    
    document.getElementById('totalRoads').textContent = filteredData.roads.length;
    document.getElementById('totalVehicles').textContent = trafficData.vehicles.length;
    document.getElementById('totalSignals').textContent = `${filteredData.signals.length} (${filteredData.intersections.length} junctions)`;
    
    // Update label to show route context
    if (currentRoute !== 'all') {
        document.getElementById('totalRoads').parentElement.querySelector('.stat-label').textContent = 
            `Roads in ${route.name}`;
    } else {
        document.getElementById('totalRoads').parentElement.querySelector('.stat-label').textContent = 'Roads';
    }
}

// Update last update time
function updateLastUpdate() {
    const now = new Date();
    document.getElementById('lastUpdate').textContent = now.toLocaleTimeString();
}

// Refresh all data
function refreshData() {
    updateTrafficTable();
    updateAlerts();
    drawTrafficMap();
    updateLastUpdate();
}

// Calculate route
function calculateRoute() {
    const start = document.getElementById('startRoad').value;
    const end = document.getElementById('endRoad').value;
    
    const startRoad = trafficData.roads.find(r => r.id === start);
    const endRoad = trafficData.roads.find(r => r.id === end);
    
    const result = document.getElementById('routeResult');
    result.innerHTML = `
        <h3 style="margin-bottom: 10px;">✓ Optimal Route Found</h3>
        <p><strong>From:</strong> ${startRoad.name}</p>
        <p><strong>To:</strong> ${endRoad.name}</p>
        <p><strong>Route:</strong> ${startRoad.name} → Central Street → ${endRoad.name}</p>
        <p><strong>Estimated Time:</strong> ${Math.round(15 + Math.random() * 10)} minutes</p>
        <p style="color: #6b7280; font-size: 0.9rem; margin-top: 10px;">
            Route optimized considering current traffic conditions.
        </p>
    `;
}

// Display user information
function displayUserInfo() {
    const loggedInUser = localStorage.getItem('loggedInUser') || sessionStorage.getItem('loggedInUser');
    
    if (loggedInUser) {
        const user = JSON.parse(loggedInUser);
        document.getElementById('userName').textContent = user.username;
        document.getElementById('userRole').textContent = user.role;
        
        // Show admin panel if user is admin
        if (user.username === 'admin' || user.role === 'Administrator') {
            document.getElementById('adminPanel').style.display = 'block';
            initAdminControls();
        }
        
        console.log('User logged in:', user);
    }
}

// Initialize admin controls
function initAdminControls() {
    generateSignalControls();
    setupRangeListeners();
}

// Generate signal control cards for each signal
function generateSignalControls() {
    const container = document.getElementById('signalControlsGrid');
    if (!container) return;
    
    container.innerHTML = trafficData.signals.map(signal => `
        <div class="signal-control-card">
            <div class="signal-control-header">
                <h4>${signal.id}</h4>
                <span class="current-state status-${signal.state.toLowerCase()}">${signal.state}</span>
            </div>
            <div class="signal-info" style="margin-bottom: 10px; font-size: 0.85rem; color: #6b7280;">
                <div>📍 ${signal.location}</div>
                <div>🚦 Intersection: ${signal.intersection}</div>
            </div>
            <div class="signal-buttons">
                <button class="btn-signal green" onclick="changeSignalColor('${signal.id}', 'GREEN')">
                    <i class="fas fa-circle"></i> Green
                </button>
                <button class="btn-signal yellow" onclick="changeSignalColor('${signal.id}', 'YELLOW')">
                    <i class="fas fa-circle"></i> Yellow
                </button>
                <button class="btn-signal red" onclick="changeSignalColor('${signal.id}', 'RED')">
                    <i class="fas fa-circle"></i> Red
                </button>
            </div>
        </div>
    `).join('');
}

// Change individual signal color
function changeSignalColor(signalId, color) {
    const signal = trafficData.signals.find(s => s.id === signalId);
    if (signal) {
        signal.state = color;
        updateSignalsGrid();
        generateSignalControls();
        drawTrafficMap();
        
        // Show notification
        showNotification(`${signalId} changed to ${color}`, 'success');
        
        // Log admin action
        logAdminAction(`Changed ${signalId} to ${color}`);
    }
}

// Set all signals to same color
function setAllSignals(color) {
    if (!confirm(`Are you sure you want to set ALL signals to ${color}?`)) return;
    
    trafficData.signals.forEach(signal => {
        signal.state = color;
    });
    
    updateSignalsGrid();
    generateSignalControls();
    drawTrafficMap();
    
    showNotification(`All signals set to ${color}`, 'success');
    logAdminAction(`Set all signals to ${color}`);
}

// Synchronize signals intelligently
function synchronizeSignals() {
    if (!confirm('Synchronize all signals based on intersection priority?')) return;
    
    trafficData.intersections.forEach(intersection => {
        const intersectionSignals = trafficData.signals.filter(s => 
            s.intersection === intersection.id
        );
        
        // Set signals based on priority
        const color = intersection.priority === 'critical' ? 'GREEN' : 
                     intersection.priority === 'high' ? 'YELLOW' : 'RED';
        
        intersectionSignals.forEach(signal => {
            signal.state = color;
        });
    });
    
    updateSignalsGrid();
    generateSignalControls();
    drawTrafficMap();
    
    showNotification('Signals synchronized by intersection priority', 'success');
    logAdminAction('Synchronized all signals');
}

// Reset to default pattern
function resetToDefault() {
    if (!confirm('Reset all signals to default pattern?')) return;
    
    const defaultPattern = ['GREEN', 'RED', 'YELLOW'];
    trafficData.signals.forEach((signal, index) => {
        signal.state = defaultPattern[index % 3];
    });
    
    updateSignalsGrid();
    generateSignalControls();
    drawTrafficMap();
    
    showNotification('Signals reset to default pattern', 'success');
    logAdminAction('Reset signals to default');
}

// Toggle emergency mode
function toggleEmergencyMode() {
    const btn = document.getElementById('emergencyToggle');
    const isActive = btn.classList.contains('active');
    
    if (isActive) {
        btn.classList.remove('active');
        btn.innerHTML = '<i class="fas fa-toggle-off"></i> OFF';
        showNotification('Emergency mode deactivated', 'info');
        logAdminAction('Deactivated emergency mode');
    } else {
        btn.classList.add('active');
        btn.innerHTML = '<i class="fas fa-toggle-on"></i> ON';
        
        // In emergency mode, all signals go red except main routes
        trafficData.signals.forEach((signal, index) => {
            signal.state = index % 3 === 0 ? 'GREEN' : 'RED';
        });
        
        updateSignalsGrid();
        generateSignalControls();
        drawTrafficMap();
        
        showNotification('Emergency mode activated - Priority routes enabled', 'warning');
        logAdminAction('Activated emergency mode');
    }
}

// Toggle automatic mode
function toggleAutoMode() {
    const btn = document.getElementById('autoToggle');
    const isActive = btn.classList.contains('active');
    
    if (isActive) {
        btn.classList.remove('active');
        btn.innerHTML = '<i class="fas fa-toggle-off"></i> OFF';
        showNotification('Automatic mode disabled - Manual control only', 'info');
        logAdminAction('Disabled automatic mode');
    } else {
        btn.classList.add('active');
        btn.innerHTML = '<i class="fas fa-toggle-on"></i> ON';
        showNotification('Automatic mode enabled', 'success');
        logAdminAction('Enabled automatic mode');
    }
}

// Lock intersection (all red)
function lockIntersection() {
    const intersectionId = prompt('Enter Intersection ID to lock (I1, I2, I3, I4, or I5):');
    
    if (!intersectionId) return;
    
    const intersection = trafficData.intersections.find(i => i.id === intersectionId.toUpperCase());
    
    if (!intersection) {
        showNotification(`Intersection ${intersectionId} not found`, 'error');
        return;
    }
    
    // Set all signals at this intersection to RED
    trafficData.signals.forEach(signal => {
        if (signal.intersection === intersection.id) {
            signal.state = 'RED';
        }
    });
    
    updateSignalsGrid();
    generateSignalControls();
    drawTrafficMap();
    
    showNotification(`Intersection ${intersection.id} locked (all red)`, 'warning');
    logAdminAction(`Locked intersection ${intersection.id}`);
}

// Setup range slider listeners
function setupRangeListeners() {
    const signalDuration = document.getElementById('signalDuration');
    const yellowDuration = document.getElementById('yellowDuration');
    
    if (signalDuration) {
        signalDuration.addEventListener('input', (e) => {
            document.getElementById('durationValue').textContent = e.target.value + 's';
        });
    }
    
    if (yellowDuration) {
        yellowDuration.addEventListener('input', (e) => {
            document.getElementById('yellowValue').textContent = e.target.value + 's';
        });
    }
}

// Show notification
function showNotification(message, type = 'info') {
    const colors = {
        success: '#10b981',
        error: '#ef4444',
        warning: '#f59e0b',
        info: '#3b82f6'
    };
    
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        background: ${colors[type]};
        color: white;
        padding: 15px 25px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        z-index: 10000;
        animation: slideInRight 0.3s ease-out;
        max-width: 400px;
        font-weight: 600;
    `;
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Log admin actions
function logAdminAction(action) {
    const logEntry = {
        timestamp: new Date().toISOString(),
        user: JSON.parse(localStorage.getItem('loggedInUser') || sessionStorage.getItem('loggedInUser')).username,
        action: action
    };
    
    console.log('Admin Action:', logEntry);
    
    // Store in session storage for audit trail
    const logs = JSON.parse(sessionStorage.getItem('adminLogs') || '[]');
    logs.push(logEntry);
    sessionStorage.setItem('adminLogs', JSON.stringify(logs));
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('loggedInUser');
        sessionStorage.removeItem('loggedInUser');
        window.location.href = 'login.html';
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', initDashboard);
