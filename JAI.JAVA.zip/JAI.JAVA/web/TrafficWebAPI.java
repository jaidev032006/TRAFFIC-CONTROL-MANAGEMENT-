import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import com.google.gson.Gson;
import java.util.*;

/**
 * Web API for Traffic Management System
 */
@WebServlet("/api/*")
public class TrafficWebAPI extends HttpServlet {
    private TrafficManagementSystem tms;
    private LiveTrafficSimulator simulator;
    private Gson gson;
    
    @Override
    public void init() throws ServletException {
        tms = new TrafficManagementSystem();
        gson = new Gson();
        setupCityInfrastructure();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        String pathInfo = request.getPathInfo();
        PrintWriter out = response.getWriter();
        
        try {
            switch (pathInfo) {
                case "/status":
                    out.print(gson.toJson(getSystemStatus()));
                    break;
                case "/roads":
                    out.print(gson.toJson(getRoadsData()));
                    break;
                case "/signals":
                    out.print(gson.toJson(getSignalsData()));
                    break;
                case "/vehicles":
                    out.print(gson.toJson(getVehiclesData()));
                    break;
                case "/route":
                    String start = request.getParameter("start");
                    String end = request.getParameter("end");
                    out.print(gson.toJson(calculateRoute(start, end)));
                    break;
                default:
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print("{\"error\": \"Endpoint not found\"}");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"" + e.getMessage() + "\"}");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("application/json");
        String pathInfo = request.getPathInfo();
        PrintWriter out = response.getWriter();
        
        try {
            if ("/start".equals(pathInfo)) {
                startSimulation();
                out.print("{\"status\": \"Simulation started\"}");
            } else if ("/adjust-signal".equals(pathInfo)) {
                String location = request.getParameter("location");
                int greenTime = Integer.parseInt(request.getParameter("greenTime"));
                int redTime = Integer.parseInt(request.getParameter("redTime"));
                tms.adjustSignalTiming(location, greenTime, redTime);
                out.print("{\"status\": \"Signal adjusted\"}");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"" + e.getMessage() + "\"}");
        }
    }
    
    private void setupCityInfrastructure() {
        // Setup 8-road network
        TrafficSignal[] signals = {
            new TrafficSignal("Downtown Center", 35, 25),
            new TrafficSignal("North Junction", 30, 30),
            new TrafficSignal("South Plaza", 25, 35),
            new TrafficSignal("East Gate", 28, 27),
            new TrafficSignal("West Terminal", 32, 28),
            new TrafficSignal("Central Square", 30, 25),
            new TrafficSignal("Park Avenue Cross", 27, 28),
            new TrafficSignal("Harbor Bridge", 33, 27)
        };
        
        String[] signalLocations = {
            "S1-Downtown", "S2-North", "S3-South", "S4-East",
            "S5-West", "S6-Central", "S7-Park", "S8-Harbor"
        };
        
        for (int i = 0; i < signals.length; i++) {
            tms.addSignal(signalLocations[i], signals[i]);
        }
        
        // Create roads
        Road[] roads = {
            new Road("R001", "Downtown Boulevard", 150, 4.5, 70),
            new Road("R002", "North Highway", 200, 6.0, 80),
            new Road("R003", "South Expressway", 180, 5.2, 75),
            new Road("R004", "East Parkway", 120, 3.8, 65),
            new Road("R005", "West Avenue", 140, 4.0, 60),
            new Road("R006", "Central Street", 160, 4.2, 70),
            new Road("R007", "Park Road", 100, 2.5, 50),
            new Road("R008", "Harbor Drive", 130, 3.5, 55)
        };
        
        // Set up connections
        roads[0].addConnectedRoad("R002");
        roads[0].addConnectedRoad("R003");
        roads[0].addConnectedRoad("R006");
        roads[1].addConnectedRoad("R004");
        roads[1].addConnectedRoad("R005");
        roads[2].addConnectedRoad("R007");
        roads[2].addConnectedRoad("R008");
        roads[3].addConnectedRoad("R001");
        roads[3].addConnectedRoad("R006");
        roads[4].addConnectedRoad("R001");
        roads[4].addConnectedRoad("R006");
        roads[5].addConnectedRoad("R000");
        roads[5].addConnectedRoad("R003");
        roads[6].addConnectedRoad("R002");
        roads[7].addConnectedRoad("R002");
        
        for (Road road : roads) {
            tms.addRoad(road.getRoadId(), road);
        }
        
        // Set initial traffic
        roads[0].setVehicleCount(120);
        roads[1].setVehicleCount(180);
        roads[2].setVehicleCount(95);
        roads[3].setVehicleCount(65);
        roads[4].setVehicleCount(85);
        roads[5].setVehicleCount(140);
        roads[6].setVehicleCount(30);
        roads[7].setVehicleCount(75);
        
        // Add vehicles
        for (int i = 1; i <= 15; i++) {
            Vehicle.VehicleType type = Vehicle.VehicleType.CAR;
            if (i % 5 == 0) type = Vehicle.VehicleType.BUS;
            if (i % 7 == 0) type = Vehicle.VehicleType.TRUCK;
            if (i == 9 || i == 15) type = Vehicle.VehicleType.EMERGENCY;
            
            Vehicle v = new Vehicle("V" + String.format("%03d", i), type, "S1-Downtown");
            tms.addVehicle(v);
        }
    }
    
    private void startSimulation() {
        tms.startSimulation();
    }
    
    private Map<String, Object> getSystemStatus() {
        Map<String, Object> status = new HashMap<>();
        status.put("activeSignals", tms.getSignals().size());
        status.put("monitoredRoads", tms.getRoads().size());
        status.put("activeVehicles", tms.getVehicles().size());
        status.put("timestamp", System.currentTimeMillis());
        return status;
    }
    
    private List<Map<String, Object>> getRoadsData() {
        List<Map<String, Object>> roadsList = new ArrayList<>();
        for (Map.Entry<String, Road> entry : tms.getRoads().entrySet()) {
            Road road = entry.getValue();
            Map<String, Object> roadData = new HashMap<>();
            roadData.put("id", road.getRoadId());
            roadData.put("name", road.getName());
            roadData.put("vehicles", road.getVehicleCount());
            roadData.put("capacity", road.getCapacity());
            roadData.put("congestion", road.getCongestionLevel().toString());
            roadData.put("avgSpeed", road.getAverageSpeed());
            roadData.put("utilization", (double)road.getVehicleCount() / road.getCapacity() * 100);
            roadsList.add(roadData);
        }
        return roadsList;
    }
    
    private List<Map<String, Object>> getSignalsData() {
        List<Map<String, Object>> signalsList = new ArrayList<>();
        for (Map.Entry<String, TrafficSignal> entry : tms.getSignals().entrySet()) {
            TrafficSignal signal = entry.getValue();
            Map<String, Object> signalData = new HashMap<>();
            signalData.put("location", entry.getKey());
            signalData.put("state", signal.getCurrentState().toString());
            signalData.put("greenDuration", signal.getGreenDuration());
            signalData.put("redDuration", signal.getRedDuration());
            signalsList.add(signalData);
        }
        return signalsList;
    }
    
    private List<Map<String, Object>> getVehiclesData() {
        List<Map<String, Object>> vehiclesList = new ArrayList<>();
        for (Vehicle v : tms.getVehicles()) {
            Map<String, Object> vehicleData = new HashMap<>();
            vehicleData.put("id", v.getVehicleId());
            vehicleData.put("type", v.getType().toString());
            vehicleData.put("location", v.getCurrentLocation());
            vehicleData.put("speed", v.getSpeed());
            vehicleData.put("priority", v.getPriority());
            vehiclesList.add(vehicleData);
        }
        return vehiclesList;
    }
    
    private Map<String, Object> calculateRoute(String start, String end) {
        String route = tms.findOptimalRoute(start, end);
        Map<String, Object> result = new HashMap<>();
        result.put("route", route);
        return result;
    }
}
