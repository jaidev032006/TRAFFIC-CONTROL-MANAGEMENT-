// City Systems Data
const citySystems = {
    downtown: {
        name: 'Downtown Business District',
        icon: 'building',
        color: '#2563eb',
        intersections: ['I1', 'I5'],
        roads: ['R001', 'R002', 'R005', 'R009'],
        navigators: [
            { id: 'NAV-001', name: 'Traffic Signal Controller', status: 'Active', location: 'I1' },
            { id: 'NAV-002', name: 'Vehicle Counter', status: 'Active', location: 'Main St' },
            { id: 'NAV-003', name: 'Congestion Monitor', status: 'Active', location: 'I5' }
        ],
        stats: {
            vehicles: 450,
            avgSpeed: 35,
            congestion: 'HIGH',
            signals: 4
        }
    },
    highway: {
        name: 'Highway 101 Corridor',
        icon: 'road',
        color: '#ef4444',
        intersections: ['I2', 'I3'],
        roads: ['R003', 'R004', 'R006', 'R007'],
        navigators: [
            { id: 'NAV-004', name: 'Speed Monitor', status: 'Active', location: 'Highway 101' },
            { id: 'NAV-005', name: 'Traffic Signal Controller', status: 'Active', location: 'I2' },
            { id: 'NAV-006', name: 'Lane Management System', status: 'Active', location: 'I3' }
        ],
        stats: {
            vehicles: 680,
            avgSpeed: 65,
            congestion: 'MODERATE',
            signals: 3
        }
    },
    residential: {
        name: 'Residential Neighborhoods',
        icon: 'home',
        color: '#10b981',
        intersections: ['I4', 'I5'],
        roads: ['R005', 'R006', 'R008'],
        navigators: [
            { id: 'NAV-007', name: 'School Zone Monitor', status: 'Active', location: 'Oak Rd' },
            { id: 'NAV-008', name: 'Pedestrian Crossing', status: 'Active', location: 'I4' },
            { id: 'NAV-009', name: 'Traffic Signal Controller', status: 'Active', location: 'I5' }
        ],
        stats: {
            vehicles: 280,
            avgSpeed: 28,
            congestion: 'LOW',
            signals: 3
        }
    },
    industrial: {
        name: 'Industrial & Warehouse District',
        icon: 'industry',
        color: '#f59e0b',
        intersections: ['I3', 'I4'],
        roads: ['R004', 'R007', 'R008', 'R010'],
        navigators: [
            { id: 'NAV-010', name: 'Heavy Vehicle Monitor', status: 'Active', location: 'West End' },
            { id: 'NAV-011', name: 'Weight Station', status: 'Active', location: 'I3' },
            { id: 'NAV-012', name: 'Freight Router', status: 'Active', location: 'I4' }
        ],
        stats: {
            vehicles: 320,
            avgSpeed: 42,
            congestion: 'MODERATE',
            signals: 2
        }
    },
    airport: {
        name: 'Airport Access Route',
        icon: 'plane',
        color: '#8b5cf6',
        intersections: ['I2', 'I3', 'I5'],
        roads: ['R003', 'R004', 'R006', 'R007'],
        navigators: [
            { id: 'NAV-013', name: 'Airport Traffic Controller', status: 'Active', location: 'I2' },
            { id: 'NAV-014', name: 'Shuttle Bus Tracker', status: 'Active', location: 'I3' },
            { id: 'NAV-015', name: 'Priority Lane Manager', status: 'Active', location: 'I5' },
            { id: 'NAV-016', name: 'Passenger Counter', status: 'Active', location: 'Airport Rd' }
        ],
        stats: {
            vehicles: 540,
            avgSpeed: 55,
            congestion: 'MODERATE',
            signals: 4
        }
    },
    commercial: {
        name: 'Commercial Shopping Hub',
        icon: 'shopping-cart',
        color: '#ec4899',
        intersections: ['I1', 'I2'],
        roads: ['R001', 'R002', 'R003'],
        navigators: [
            { id: 'NAV-017', name: 'Parking Lot Monitor', status: 'Active', location: 'Mall Area' },
            { id: 'NAV-018', name: 'Peak Hour Controller', status: 'Active', location: 'I1' },
            { id: 'NAV-019', name: 'Delivery Zone Manager', status: 'Active', location: 'I2' }
        ],
        stats: {
            vehicles: 420,
            avgSpeed: 30,
            congestion: 'HIGH',
            signals: 3
        }
    }
};

let selectedSystem = null;
let mapZoom = 1;

// Sample traffic data
const trafficData = {
    roads: [
        { id: 'R001', name: 'Main Street (W-E)', vehicles: 120, capacity: 150, congestion: 'HIGH', utilization: 80 },
        { id: 'R002', name: 'North Avenue (W-E)', vehicles: 95, capacity: 180, congestion: 'MODERATE', utilization: 53 },
        { id: 'R003', name: 'Northeast Road', vehicles: 65, capacity: 120, congestion: 'MODERATE', utilization: 54 },
        { id: 'R004', name: 'East Boulevard', vehicles: 180, capacity: 200, congestion: 'SEVERE', utilization: 90 },
        { id: 'R005', name: 'West Highway (N-S)', vehicles: 85, capacity: 140, congestion: 'MODERATE', utilization: 61 },
        { id: 'R006', name: 'Central Street (N-S)', vehicles: 140, capacity: 160, congestion: 'HIGH', utilization: 88 },
        { id: 'R007', name: 'East Parkway (N-S)', vehicles: 75, capacity: 130, congestion: 'MODERATE', utilization: 58 },
        { id: 'R008', name: 'South Express (N-S)', vehicles: 50, capacity: 120, congestion: 'LOW', utilization: 42 },
        { id: 'R009', name: 'Downtown Loop', vehicles: 110, capacity: 140, congestion: 'HIGH', utilization: 79 },
        { id: 'R010', name: 'Airport Access', vehicles: 95, capacity: 160, congestion: 'MODERATE', utilization: 59 }
    ],
    signals: [
        { id: 'S1', state: 'GREEN', intersection: 'I1' },
        { id: 'S2', state: 'RED', intersection: 'I2' },
        { id: 'S3', state: 'YELLOW', intersection: 'I3' },
        { id: 'S4', state: 'GREEN', intersection: 'I4' },
        { id: 'S5', state: 'RED', intersection: 'I5' },
        { id: 'S6', state: 'GREEN', intersection: 'I1' },
        { id: 'S7', state: 'YELLOW', intersection: 'I2' },
        { id: 'S8', state: 'RED', intersection: 'I3' }
    ],
    vehicles: 156
};

// Activity feed data
const activityFeed = [
    { type: 'danger', icon: 'exclamation-triangle', title: 'High Congestion Alert', description: 'East Boulevard experiencing severe traffic. Consider alternate routes.', time: '2 min ago' },
    { type: 'warning', icon: 'traffic-light', title: 'Signal Timing Updated', description: 'Downtown Center intersection signals adjusted for peak traffic.', time: '5 min ago' },
    { type: 'success', icon: 'check-circle', title: 'Traffic Cleared', description: 'South Express congestion has been resolved. Normal flow restored.', time: '8 min ago' },
    { type: 'info', icon: 'car', title: 'Emergency Vehicle Detected', description: 'Ambulance on Main Street. Priority routing activated.', time: '12 min ago' },
    { type: 'warning', icon: 'exclamation-circle', title: 'Moderate Congestion', description: 'Central Street showing increased traffic volume.', time: '15 min ago' },
    { type: 'info', icon: 'sync', title: 'System Update', description: 'Traffic prediction algorithms updated successfully.', time: '20 min ago' },
    { type: 'success', icon: 'chart-line', title: 'Performance Improved', description: 'Average travel time reduced by 2 minutes.', time: '25 min ago' }
];

// Initialize dashboard
function initDashboard() {
    displayUserCredentials();
    drawCityMap();
    updateStats();
    createTrafficFlowChart();
    createUtilizationChart();
    createSignalChart();
    updateRoadStatusTable();
    updateCongestionLevels();
    updateActivityFeed();
    
    // Update every 3 seconds
    setInterval(() => {
        simulateTrafficChanges();
        updateStats();
        updateRoadStatusTable();
        updateCongestionLevels();
    }, 3000);
}

// Display user credentials
function displayUserCredentials() {
    const loggedInUser = localStorage.getItem('loggedInUser') || sessionStorage.getItem('loggedInUser');
    
    if (loggedInUser) {
        const user = JSON.parse(loggedInUser);
        document.getElementById('userNameDisplay').textContent = user.username;
        document.getElementById('userRoleDisplay').textContent = user.role;
        
        // Calculate login duration
        const loginTime = new Date(user.loginTime);
        const duration = Math.floor((new Date() - loginTime) / 60000); // minutes
        document.getElementById('loginTime').textContent = `${duration} min ago`;
        
        // Set access level based on role
        const accessLevels = {
            'Administrator': 'Full Access',
            'Traffic Operator': 'Control Access',
            'Viewer': 'Read Only',
            'Demo User': 'Limited Access'
        };
        document.getElementById('accessLevel').textContent = accessLevels[user.role] || 'Standard Access';
    }
}

// Draw Interactive City Map
function drawCityMap() {
    const svg = document.getElementById('cityMap');
    svg.innerHTML = '';
    
    // City zones with positions
    const zones = [
        { id: 'downtown', x: 300, y: 200, name: 'Downtown', color: '#2563eb' },
        { id: 'highway', x: 700, y: 150, name: 'Highway 101', color: '#ef4444' },
        { id: 'residential', x: 300, y: 400, name: 'Residential', color: '#10b981' },
        { id: 'industrial', x: 700, y: 400, name: 'Industrial', color: '#f59e0b' },
        { id: 'airport', x: 950, y: 300, name: 'Airport', color: '#8b5cf6' },
        { id: 'commercial', x: 500, y: 100, name: 'Commercial', color: '#ec4899' }
    ];
    
    // Draw roads connecting zones
    const roads = [
        { from: 'downtown', to: 'commercial' },
        { from: 'downtown', to: 'residential' },
        { from: 'commercial', to: 'highway' },
        { from: 'highway', to: 'industrial' },
        { from: 'highway', to: 'airport' },
        { from: 'residential', to: 'industrial' },
        { from: 'industrial', to: 'airport' }
    ];
    
    roads.forEach(road => {
        const from = zones.find(z => z.id === road.from);
        const to = zones.find(z => z.id === road.to);
        
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', from.x);
        line.setAttribute('y1', from.y);
        line.setAttribute('x2', to.x);
        line.setAttribute('y2', to.y);
        line.setAttribute('stroke', '#cbd5e1');
        line.setAttribute('stroke-width', '8');
        line.setAttribute('stroke-dasharray', '10,5');
        svg.appendChild(line);
    });
    
    // Draw zone circles
    zones.forEach(zone => {
        // Zone circle
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', zone.x);
        circle.setAttribute('cy', zone.y);
        circle.setAttribute('r', 60);
        circle.setAttribute('fill', zone.color);
        circle.setAttribute('opacity', '0.8');
        circle.setAttribute('cursor', 'pointer');
        circle.setAttribute('class', 'zone-circle');
        circle.onclick = () => selectCitySystem(zone.id);
        
        // Hover effect
        circle.onmouseover = () => circle.setAttribute('opacity', '1');
        circle.onmouseout = () => circle.setAttribute('opacity', '0.8');
        
        svg.appendChild(circle);
        
        // Zone icon
        const iconGroup = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        iconGroup.setAttribute('x', zone.x);
        iconGroup.setAttribute('y', zone.y + 10);
        iconGroup.setAttribute('text-anchor', 'middle');
        iconGroup.setAttribute('fill', 'white');
        iconGroup.setAttribute('font-size', '24');
        iconGroup.setAttribute('font-weight', 'bold');
        iconGroup.setAttribute('pointer-events', 'none');
        iconGroup.textContent = citySystems[zone.id].stats.vehicles;
        svg.appendChild(iconGroup);
        
        // Zone name
        const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        text.setAttribute('x', zone.x);
        text.setAttribute('y', zone.y + 85);
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('fill', '#1f2937');
        text.setAttribute('font-size', '14');
        text.setAttribute('font-weight', 'bold');
        text.setAttribute('pointer-events', 'none');
        text.textContent = zone.name;
        svg.appendChild(text);
    });
}

// Select City System
function selectCitySystem(systemId) {
    selectedSystem = systemId;
    const system = citySystems[systemId];
    
    // Show system details panel
    const panel = document.getElementById('systemDetailsPanel');
    panel.style.display = 'block';
    
    document.getElementById('systemName').textContent = system.name;
    
    // Generate system details
    const content = document.getElementById('systemDetailsContent');
    content.innerHTML = `
        <div class="detail-grid">
            <div class="detail-item">
                <h4>Active Vehicles</h4>
                <div class="value">${system.stats.vehicles}</div>
            </div>
            <div class="detail-item">
                <h4>Average Speed</h4>
                <div class="value">${system.stats.avgSpeed} km/h</div>
            </div>
            <div class="detail-item">
                <h4>Congestion Level</h4>
                <div class="value" style="color: ${getCongestionColorValue(system.stats.congestion)}">${system.stats.congestion}</div>
            </div>
            <div class="detail-item">
                <h4>Traffic Signals</h4>
                <div class="value">${system.stats.signals}</div>
            </div>
        </div>
        
        <div style="margin-top: 30px;">
            <h3 style="margin-bottom: 15px; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-compass"></i> System Navigators
            </h3>
            <div class="navigator-list">
                ${system.navigators.map(nav => `
                    <div class="navigator-item">
                        <div>
                            <strong>${nav.name}</strong>
                            <div style="font-size: 0.85rem; color: #6b7280;">
                                <i class="fas fa-map-marker-alt"></i> ${nav.location}
                            </div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <span style="color: #10b981; font-weight: 600;">
                                <i class="fas fa-check-circle"></i> ${nav.status}
                            </span>
                            <button class="btn btn-primary" style="padding: 8px 16px; font-size: 0.85rem;" onclick="navigateToSystem('${systemId}', '${nav.id}')">
                                <i class="fas fa-arrow-right"></i> View
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
        
        <div style="margin-top: 20px; display: flex; gap: 15px;">
            <button class="btn btn-primary" onclick="navigateToTrafficMap('${systemId}')">
                <i class="fas fa-map"></i> View on Traffic Map
            </button>
            <button class="btn btn-primary" onclick="navigateToIntersections('${systemId}')">
                <i class="fas fa-traffic-light"></i> View Intersections
            </button>
        </div>
    `;
    
    // Scroll to panel
    panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Close system panel
function closeSystemPanel() {
    document.getElementById('systemDetailsPanel').style.display = 'none';
    selectedSystem = null;
}

// Navigate to traffic map with system filter
function navigateToTrafficMap(systemId) {
    localStorage.setItem('selectedRoute', systemId);
    window.location.href = 'index.html';
}

// Navigate to intersections with system filter
function navigateToIntersections(systemId) {
    localStorage.setItem('selectedSystem', systemId);
    window.location.href = 'intersections.html';
}

// Navigate to specific navigator
function navigateToSystem(systemId, navigatorId) {
    localStorage.setItem('selectedRoute', systemId);
    localStorage.setItem('selectedNavigator', navigatorId);
    window.location.href = 'index.html';
}

// Map controls
function zoomIn() {
    mapZoom = Math.min(mapZoom + 0.2, 2);
    applyMapZoom();
}

function zoomOut() {
    mapZoom = Math.max(mapZoom - 0.2, 0.5);
    applyMapZoom();
}

function resetMap() {
    mapZoom = 1;
    applyMapZoom();
}

function applyMapZoom() {
    const svg = document.getElementById('cityMap');
    svg.style.transform = `scale(${mapZoom})`;
    svg.style.transformOrigin = 'center';
}

// Helper function
function getCongestionColorValue(congestion) {
    const colors = {
        'LOW': '#10b981',
        'MODERATE': '#fbbf24',
        'HIGH': '#f97316',
        'SEVERE': '#ef4444'
    };
    return colors[congestion] || '#6b7280';
}

// Update statistics
function updateStats() {
    document.getElementById('totalRoadsCount').textContent = trafficData.roads.length;
    document.getElementById('totalVehiclesCount').textContent = trafficData.vehicles;
    document.getElementById('totalSignalsCount').textContent = trafficData.signals.length;
    
    const alerts = trafficData.roads.filter(r => r.congestion === 'HIGH' || r.congestion === 'SEVERE').length;
    document.getElementById('alertsCount').textContent = alerts;
}

// Traffic Flow Chart (Line Chart)
function createTrafficFlowChart() {
    const ctx = document.getElementById('trafficFlowChart').getContext('2d');
    
    const labels = [];
    const data = [];
    
    // Generate 24 hours of data
    for (let i = 23; i >= 0; i--) {
        const hour = new Date();
        hour.setHours(hour.getHours() - i);
        labels.push(hour.getHours() + ':00');
        
        // Simulate traffic pattern (higher during rush hours)
        const h = hour.getHours();
        let traffic = 50;
        if (h >= 7 && h <= 9) traffic = 120 + Math.random() * 30; // Morning rush
        else if (h >= 17 && h <= 19) traffic = 140 + Math.random() * 30; // Evening rush
        else if (h >= 22 || h <= 5) traffic = 20 + Math.random() * 10; // Night
        else traffic = 60 + Math.random() * 40; // Normal
        
        data.push(Math.round(traffic));
    }
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Vehicles per Hour',
                data: data,
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Vehicles'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Time (24h)'
                    }
                }
            }
        }
    });
}

// Road Utilization Chart (Bar Chart)
function createUtilizationChart() {
    const ctx = document.getElementById('utilizationChart').getContext('2d');
    
    const roadNames = trafficData.roads.map(r => r.name.split(' ')[0] + ' ' + r.name.split(' ')[1]);
    const utilizationData = trafficData.roads.map(r => r.utilization);
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: roadNames,
            datasets: [{
                label: 'Utilization %',
                data: utilizationData,
                backgroundColor: utilizationData.map(util => {
                    if (util >= 85) return '#ef4444';
                    if (util >= 60) return '#f97316';
                    if (util >= 30) return '#fbbf24';
                    return '#10b981';
                }),
                borderWidth: 0,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Utilization %'
                    }
                },
                x: {
                    ticks: {
                        maxRotation: 45,
                        minRotation: 45
                    }
                }
            }
        }
    });
}

// Signal Distribution Chart (Pie Chart)
function createSignalChart() {
    const ctx = document.getElementById('signalChart').getContext('2d');
    
    const signalCounts = {
        GREEN: trafficData.signals.filter(s => s.state === 'GREEN').length,
        YELLOW: trafficData.signals.filter(s => s.state === 'YELLOW').length,
        RED: trafficData.signals.filter(s => s.state === 'RED').length
    };
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Green Signals', 'Yellow Signals', 'Red Signals'],
            datasets: [{
                data: [signalCounts.GREEN, signalCounts.YELLOW, signalCounts.RED],
                backgroundColor: ['#10b981', '#fbbf24', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Update Road Status Table
function updateRoadStatusTable() {
    const tbody = document.getElementById('roadStatusTable');
    tbody.innerHTML = '';
    
    trafficData.roads.forEach(road => {
        const row = document.createElement('tr');
        
        const statusClass = road.congestion.toLowerCase().replace('_', '-');
        
        row.innerHTML = `
            <td style="font-weight: 600;">${road.name}</td>
            <td>${road.vehicles}</td>
            <td>${road.capacity}</td>
            <td><span class="status-badge status-${statusClass}">${road.congestion}</span></td>
        `;
        
        tbody.appendChild(row);
    });
}

// Update Congestion Levels
function updateCongestionLevels() {
    const container = document.getElementById('congestionLevels');
    container.innerHTML = '';
    
    trafficData.roads.forEach(road => {
        const progressDiv = document.createElement('div');
        progressDiv.className = 'progress-container';
        
        let levelClass = 'low';
        if (road.utilization >= 85) levelClass = 'severe';
        else if (road.utilization >= 60) levelClass = 'high';
        else if (road.utilization >= 30) levelClass = 'moderate';
        
        progressDiv.innerHTML = `
            <div class="progress-label">
                <span style="font-weight: 600;">${road.name}</span>
                <span style="color: #6b7280;">${road.utilization}%</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill ${levelClass}" style="width: ${road.utilization}%"></div>
            </div>
        `;
        
        container.appendChild(progressDiv);
    });
}

// Update Activity Feed
function updateActivityFeed() {
    const feed = document.getElementById('liveFeed');
    feed.innerHTML = '';
    
    activityFeed.forEach(item => {
        const feedItem = document.createElement('div');
        feedItem.className = 'feed-item';
        
        feedItem.innerHTML = `
            <div class="feed-icon ${item.type}">
                <i class="fas fa-${item.icon}"></i>
            </div>
            <div class="feed-content">
                <div class="feed-title">${item.title}</div>
                <div class="feed-description">${item.description}</div>
                <div class="feed-time"><i class="fas fa-clock"></i> ${item.time}</div>
            </div>
        `;
        
        feed.appendChild(feedItem);
    });
}

// Simulate traffic changes
function simulateTrafficChanges() {
    trafficData.roads.forEach(road => {
        const change = Math.floor(Math.random() * 11) - 5;
        road.vehicles = Math.max(0, Math.min(road.capacity, road.vehicles + change));
        road.utilization = Math.round((road.vehicles / road.capacity) * 100);
        
        // Update congestion
        if (road.utilization < 30) road.congestion = 'LOW';
        else if (road.utilization < 60) road.congestion = 'MODERATE';
        else if (road.utilization < 85) road.congestion = 'HIGH';
        else road.congestion = 'SEVERE';
    });
    
    // Random vehicle count change
    trafficData.vehicles = Math.max(100, Math.min(200, trafficData.vehicles + Math.floor(Math.random() * 11) - 5));
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('loggedInUser');
        sessionStorage.removeItem('loggedInUser');
        window.location.href = 'login.html';
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', initDashboard);
