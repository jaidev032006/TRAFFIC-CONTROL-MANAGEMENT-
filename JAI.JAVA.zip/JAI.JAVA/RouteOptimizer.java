import java.util.*;

/**
 * Route Optimizer using Dijkstra's algorithm for optimal path finding
 */
public class RouteOptimizer {
    
    public RouteOptimizer() {
    }
    
    /**
     * Calculate optimal route considering traffic conditions
     */
    public String calculateOptimalRoute(String start, String destination, Map<String, Road> roads) {
        System.out.println("\n=== Route Optimization ===");
        System.out.println("Start: " + start);
        System.out.println("Destination: " + destination);
        
        // Build graph
        Map<String, List<RouteEdge>> graph = buildGraph(roads);
        
        // Run Dijkstra's algorithm
        Map<String, Double> distances = new HashMap<>();
        Map<String, String> previous = new HashMap<>();
        PriorityQueue<RouteNode> queue = new PriorityQueue<>(Comparator.comparingDouble(n -> n.distance));
        Set<String> visited = new HashSet<>();
        
        // Initialize
        for (String roadId : roads.keySet()) {
            distances.put(roadId, Double.POSITIVE_INFINITY);
        }
        distances.put(start, 0.0);
        queue.offer(new RouteNode(start, 0.0));
        
        // Process
        while (!queue.isEmpty()) {
            RouteNode current = queue.poll();
            String currentRoad = current.roadId;
            
            if (visited.contains(currentRoad)) continue;
            visited.add(currentRoad);
            
            if (currentRoad.equals(destination)) break;
            
            List<RouteEdge> neighbors = graph.getOrDefault(currentRoad, new ArrayList<>());
            for (RouteEdge edge : neighbors) {
                if (visited.contains(edge.to)) continue;
                
                double newDistance = distances.get(currentRoad) + edge.weight;
                if (newDistance < distances.get(edge.to)) {
                    distances.put(edge.to, newDistance);
                    previous.put(edge.to, currentRoad);
                    queue.offer(new RouteNode(edge.to, newDistance));
                }
            }
        }
        
        // Reconstruct path
        return reconstructPath(previous, start, destination, distances.get(destination));
    }
    
    private Map<String, List<RouteEdge>> buildGraph(Map<String, Road> roads) {
        Map<String, List<RouteEdge>> graph = new HashMap<>();
        
        for (Road road : roads.values()) {
            String from = road.getRoadId();
            
            for (String connectedRoadId : road.getConnectedRoads()) {
                Road connectedRoad = roads.get(connectedRoadId);
                if (connectedRoad != null) {
                    // Weight based on travel time (considering congestion)
                    double weight = connectedRoad.getEstimatedTravelTime();
                    
                    if (!graph.containsKey(from)) {
                        graph.put(from, new ArrayList<>());
                    }
                    graph.get(from).add(new RouteEdge(from, connectedRoadId, weight));
                }
            }
        }
        
        return graph;
    }
    
    private String reconstructPath(Map<String, String> previous, String start, String destination, double totalTime) {
        List<String> path = new ArrayList<>();
        String current = destination;
        
        while (current != null && !current.equals(start)) {
            path.add(0, current);
            current = previous.get(current);
        }
        
        if (current != null) {
            path.add(0, start);
        }
        
        StringBuilder result = new StringBuilder();
        result.append("\n✓ Optimal Route Found:\n");
        
        if (path.isEmpty() || !path.get(0).equals(start)) {
            result.append("No route available from ").append(start).append(" to ").append(destination);
        } else {
            for (int i = 0; i < path.size(); i++) {
                result.append(path.get(i));
                if (i < path.size() - 1) {
                    result.append(" → ");
                }
            }
            result.append("\nEstimated Travel Time: ").append(String.format("%.1f", totalTime)).append(" minutes");
        }
        
        System.out.println(result.toString());
        return result.toString();
    }
    
    /**
     * Helper class for graph edges
     */
    private static class RouteEdge {
        String from;
        String to;
        double weight;
        
        RouteEdge(String from, String to, double weight) {
            this.from = from;
            this.to = to;
            this.weight = weight;
        }
    }
    
    /**
     * Helper class for priority queue
     */
    private static class RouteNode {
        String roadId;
        double distance;
        
        RouteNode(String roadId, double distance) {
            this.roadId = roadId;
            this.distance = distance;
        }
    }
}
