/**
 * Demo application to demonstrate the Traffic Management System
 */
public class TrafficSimulationDemo {
    
    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════════════════════╗");
        System.out.println("║   Urban Traffic Management & Simulation System        ║");
        System.out.println("║   Version 1.0 - October 2025                          ║");
        System.out.println("╚════════════════════════════════════════════════════════╝\n");
        
        // Initialize the traffic management system
        TrafficManagementSystem tms = new TrafficManagementSystem();
        
        // Setup city infrastructure
        setupCityInfrastructure(tms);
        
        // Add vehicles to the system
        addVehiclesToSystem(tms);
        
        // Start the simulation
        tms.startSimulation();
        
        // Simulate for a few seconds
        try {
            System.out.println("\n⏱️  Simulating traffic for 10 seconds...\n");
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Display updated status
        tms.displaySystemStatus();
        
        // Demonstrate route optimization
        demonstrateRouteOptimization(tms);
        
        // Demonstrate dynamic signal adjustment
        demonstrateSignalAdjustment(tms);
        
        System.out.println("\n╔════════════════════════════════════════════════════════╗");
        System.out.println("║   Simulation Complete                                 ║");
        System.out.println("╚════════════════════════════════════════════════════════╝");
    }
    
    private static void setupCityInfrastructure(TrafficManagementSystem tms) {
        System.out.println("🏗️  Setting up city infrastructure...\n");
        
        // Create traffic signals at major intersections
        TrafficSignal signal1 = new TrafficSignal("Main St & 1st Ave", 30, 25);
        TrafficSignal signal2 = new TrafficSignal("Main St & 2nd Ave", 25, 30);
        TrafficSignal signal3 = new TrafficSignal("Oak St & 1st Ave", 20, 35);
        TrafficSignal signal4 = new TrafficSignal("Oak St & 2nd Ave", 28, 27);
        
        tms.addSignal("Main-1st", signal1);
        tms.addSignal("Main-2nd", signal2);
        tms.addSignal("Oak-1st", signal3);
        tms.addSignal("Oak-2nd", signal4);
        
        // Create road network
        Road road1 = new Road("R001", "Main Street East", 100, 2.5, 60);
        Road road2 = new Road("R002", "Main Street West", 100, 2.5, 60);
        Road road3 = new Road("R003", "Oak Street North", 80, 1.8, 50);
        Road road4 = new Road("R004", "Oak Street South", 80, 1.8, 50);
        Road road5 = new Road("R005", "1st Avenue", 120, 3.0, 70);
        Road road6 = new Road("R006", "2nd Avenue", 90, 2.2, 55);
        
        // Set up road connections for route optimization
        road1.addConnectedRoad("R003");
        road1.addConnectedRoad("R005");
        road2.addConnectedRoad("R004");
        road2.addConnectedRoad("R006");
        road3.addConnectedRoad("R001");
        road3.addConnectedRoad("R006");
        road4.addConnectedRoad("R002");
        road4.addConnectedRoad("R005");
        road5.addConnectedRoad("R001");
        road5.addConnectedRoad("R004");
        road6.addConnectedRoad("R002");
        road6.addConnectedRoad("R003");
        
        tms.addRoad("R001", road1);
        tms.addRoad("R002", road2);
        tms.addRoad("R003", road3);
        tms.addRoad("R004", road4);
        tms.addRoad("R005", road5);
        tms.addRoad("R006", road6);
        
        // Simulate different traffic densities
        road1.setVehicleCount(85);  // High congestion
        road2.setVehicleCount(45);  // Moderate
        road3.setVehicleCount(70);  // High
        road4.setVehicleCount(25);  // Low
        road5.setVehicleCount(95);  // Severe congestion
        road6.setVehicleCount(50);  // Moderate
        
        System.out.println();
    }
    
    private static void addVehiclesToSystem(TrafficManagementSystem tms) {
        System.out.println("🚗 Adding vehicles to the system...\n");
        
        Vehicle car1 = new Vehicle("V001", Vehicle.VehicleType.CAR, "Main-1st");
        car1.setDestination("Oak-2nd");
        
        Vehicle bus1 = new Vehicle("V002", Vehicle.VehicleType.BUS, "Main-2nd");
        bus1.setDestination("Oak-1st");
        
        Vehicle truck1 = new Vehicle("V003", Vehicle.VehicleType.TRUCK, "Oak-1st");
        truck1.setDestination("Main-2nd");
        
        Vehicle emergency1 = new Vehicle("V004", Vehicle.VehicleType.EMERGENCY, "Oak-2nd");
        emergency1.setDestination("Main-1st");
        
        Vehicle car2 = new Vehicle("V005", Vehicle.VehicleType.CAR, "Main-1st");
        car2.setDestination("Main-2nd");
        
        tms.addVehicle(car1);
        tms.addVehicle(bus1);
        tms.addVehicle(truck1);
        tms.addVehicle(emergency1);
        tms.addVehicle(car2);
        
        System.out.println("Added " + tms.getVehicles().size() + " vehicles");
        System.out.println();
    }
    
    private static void demonstrateRouteOptimization(TrafficManagementSystem tms) {
        System.out.println("\n════════════════════════════════════════");
        System.out.println("🗺️  Route Optimization Demonstration");
        System.out.println("════════════════════════════════════════");
        
        // Calculate optimal routes
        tms.findOptimalRoute("R001", "R004");
        System.out.println();
        tms.findOptimalRoute("R005", "R006");
        System.out.println();
        tms.findOptimalRoute("R003", "R002");
    }
    
    private static void demonstrateSignalAdjustment(TrafficManagementSystem tms) {
        System.out.println("\n════════════════════════════════════════");
        System.out.println("⚙️  Dynamic Signal Timing Adjustment");
        System.out.println("════════════════════════════════════════");
        
        System.out.println("\nAdjusting signal timing based on congestion...");
        
        // Adjust signals in high-congestion areas
        tms.adjustSignalTiming("Main-1st", 40, 20);  // Increase green time
        tms.adjustSignalTiming("Oak-1st", 35, 25);   // Increase green time
        
        System.out.println("\n✓ Signal timings optimized for current traffic conditions");
    }
}
