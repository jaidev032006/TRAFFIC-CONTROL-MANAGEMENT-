import java.util.*;
import java.util.concurrent.*;

/**
 * Enhanced Live Traffic Simulator with real-time updates
 */
public class LiveTrafficSimulator {
    private TrafficManagementSystem tms;
    private ScheduledExecutorService scheduler;
    private Random random;
    private boolean isRunning;
    private int simulationTime;
    
    public LiveTrafficSimulator(TrafficManagementSystem tms) {
        this.tms = tms;
        this.scheduler = Executors.newScheduledThreadPool(3);
        this.random = new Random();
        this.isRunning = false;
        this.simulationTime = 0;
    }
    
    public void startLiveSimulation(int durationSeconds) {
        System.out.println("\n╔════════════════════════════════════════════════════════╗");
        System.out.println("║        LIVE TRAFFIC SIMULATION STARTED                ║");
        System.out.println("║        Duration: " + durationSeconds + " seconds                            ║");
        System.out.println("╚════════════════════════════════════════════════════════╝\n");
        
        isRunning = true;
        
        // Schedule vehicle movement simulation
        scheduler.scheduleAtFixedRate(() -> {
            if (isRunning) {
                simulateVehicleMovement();
            }
        }, 0, 2, TimeUnit.SECONDS);
        
        // Schedule congestion monitoring
        scheduler.scheduleAtFixedRate(() -> {
            if (isRunning) {
                monitorAndDisplayTraffic();
            }
        }, 0, 3, TimeUnit.SECONDS);
        
        // Schedule traffic updates
        scheduler.scheduleAtFixedRate(() -> {
            if (isRunning) {
                updateTrafficConditions();
            }
        }, 0, 4, TimeUnit.SECONDS);
        
        // Schedule time counter
        scheduler.scheduleAtFixedRate(() -> {
            if (isRunning) {
                simulationTime++;
                displaySimulationTime();
            }
        }, 1, 1, TimeUnit.SECONDS);
        
        // Stop after duration
        scheduler.schedule(() -> {
            stopSimulation();
        }, durationSeconds, TimeUnit.SECONDS);
    }
    
    private void simulateVehicleMovement() {
        Map<String, Road> roads = tms.getRoads();
        List<Vehicle> vehicles = tms.getVehicles();
        
        System.out.println("\n🚗 Vehicle Movement Update:");
        
        for (Vehicle vehicle : vehicles) {
            // Random movement between roads
            List<String> roadIds = new ArrayList<>(roads.keySet());
            if (!roadIds.isEmpty()) {
                String newRoad = roadIds.get(random.nextInt(roadIds.size()));
                Road road = roads.get(newRoad);
                
                // Remove from old road if exists
                if (vehicle.getCurrentRoad() != null && roads.containsKey(vehicle.getCurrentRoad())) {
                    roads.get(vehicle.getCurrentRoad()).removeVehicle();
                }
                
                // Add to new road
                road.addVehicle();
                vehicle.move(road.getName(), newRoad);
                vehicle.setSpeed(road.getAverageSpeed());
                
                System.out.println("   " + vehicle.getVehicleId() + " (" + vehicle.getType() + 
                                 ") moved to " + road.getName() + 
                                 " @ " + String.format("%.1f", vehicle.getSpeed()) + " km/h");
            }
        }
    }
    
    private void monitorAndDisplayTraffic() {
        Map<String, Road> roads = tms.getRoads();
        
        System.out.println("\n📊 Real-Time Traffic Status:");
        System.out.println("┌─────────────────────────────┬──────────┬─────────────┬────────────┐");
        System.out.println("│ Road Name                   │ Vehicles │ Congestion  │ Avg Speed  │");
        System.out.println("├─────────────────────────────┼──────────┼─────────────┼────────────┤");
        
        for (Map.Entry<String, Road> entry : roads.entrySet()) {
            Road road = entry.getValue();
            String congestion = getCongestionEmoji(road.getCongestionLevel());
            String name = String.format("%-27s", road.getName());
            String vehicles = String.format("%3d/%-3d", road.getVehicleCount(), road.getCapacity());
            String level = String.format("%-11s", road.getCongestionLevel() + " " + congestion);
            String speed = String.format("%.0f km/h", road.getAverageSpeed());
            
            System.out.println("│ " + name + " │ " + vehicles + " │ " + level + " │ " + speed + "    │");
        }
        System.out.println("└─────────────────────────────┴──────────┴─────────────┴────────────┘");
        
        // Check and display congestion alerts
        tms.getCongestionMonitor().clearAlerts();
        for (Road road : roads.values()) {
            tms.getCongestionMonitor().checkCongestion(road);
        }
    }
    
    private void updateTrafficConditions() {
        Map<String, Road> roads = tms.getRoads();
        
        System.out.println("\n🔄 Traffic Condition Update:");
        
        // Randomly add/remove vehicles to simulate dynamic traffic
        for (Road road : roads.values()) {
            int change = random.nextInt(11) - 5; // -5 to +5 vehicles
            int newCount = Math.max(0, Math.min(road.getCapacity(), 
                                   road.getVehicleCount() + change));
            
            if (change != 0) {
                road.setVehicleCount(newCount);
                System.out.println("   " + road.getName() + ": " + 
                                 (change > 0 ? "+" + change : change) + " vehicles");
            }
        }
    }
    
    private void displaySimulationTime() {
        System.out.print("\r⏱️  Simulation Time: " + simulationTime + "s");
    }
    
    private String getCongestionEmoji(Road.CongestionLevel level) {
        switch (level) {
            case LOW:
                return "🟢";
            case MODERATE:
                return "🟡";
            case HIGH:
                return "🟠";
            case SEVERE:
                return "🔴";
            default:
                return "⚪";
        }
    }
    
    public void stopSimulation() {
        System.out.println("\n\n╔════════════════════════════════════════════════════════╗");
        System.out.println("║        LIVE SIMULATION STOPPED                        ║");
        System.out.println("║        Total Duration: " + simulationTime + " seconds                      ║");
        System.out.println("╚════════════════════════════════════════════════════════╝");
        
        isRunning = false;
        scheduler.shutdown();
        
        // Final statistics
        displayFinalStatistics();
    }
    
    private void displayFinalStatistics() {
        Map<String, Road> roads = tms.getRoads();
        
        System.out.println("\n📈 Final Traffic Statistics:");
        
        int totalVehicles = 0;
        int congestedRoads = 0;
        double avgUtilization = 0;
        
        for (Road road : roads.values()) {
            totalVehicles += road.getVehicleCount();
            if (road.isCongested()) {
                congestedRoads++;
            }
            avgUtilization += (double) road.getVehicleCount() / road.getCapacity();
        }
        
        avgUtilization = (avgUtilization / roads.size()) * 100;
        
        System.out.println("   Total Roads Monitored: " + roads.size());
        System.out.println("   Total Vehicles: " + totalVehicles);
        System.out.println("   Congested Roads: " + congestedRoads);
        System.out.println("   Average Road Utilization: " + String.format("%.1f%%", avgUtilization));
        System.out.println("   Active Traffic Signals: " + tms.getSignals().size());
        System.out.println("   Simulation Duration: " + simulationTime + " seconds");
    }
    
    public TrafficManagementSystem getTrafficManagementSystem() {
        return tms;
    }
}
