# Urban Traffic Management & Simulation System

## Overview
A comprehensive digital application to simulate and manage urban traffic, including signal timing, congestion alerts, and route optimization. Now featuring **LIVE SIMULATION** with 4 or 8 road networks with real-time updates!

## Features

### 1. **Traffic Signal Management**
- Automated signal timing with configurable durations
- Real-time signal state monitoring (RED, YELLOW, GREEN)
- Dynamic signal timing adjustment based on traffic conditions
- Support for multiple intersections

### 2. **Congestion Monitoring & Alerts**
- Real-time traffic congestion detection
- Four-level congestion classification: LOW, MODERATE, HIGH, SEVERE
- Automatic alert generation for high-congestion areas
- Utilization percentage tracking
- Recommendations for alternate routes

### 3. **Route Optimization**
- Dijkstra's algorithm-based optimal path finding
- Considers real-time traffic conditions
- Calculates estimated travel time
- Suggests fastest routes avoiding congestion

### 4. **Vehicle Management**
- Support for multiple vehicle types (CAR, BUS, TRUCK, MOTORCYCLE, EMERGENCY)
- Vehicle priority system (emergency vehicles get highest priority)
- Real-time vehicle tracking
- Location and destination management

### 5. **Road Network Simulation**
- Configurable road capacity and speed limits
- Dynamic vehicle count tracking
- Connected road system for realistic navigation
- Average speed calculation based on congestion

## System Architecture

```
TrafficManagementSystem (Main Controller)
    ├── TrafficSignal (Signal timing and state management)
    ├── Road (Road network and capacity management)
    ├── Vehicle (Vehicle tracking and management)
    ├── CongestionMonitor (Congestion detection and alerts)
    ├── RouteOptimizer (Optimal path calculation)
    └── LiveTrafficSimulator (Real-time simulation engine) ⭐ NEW!
```

## Live Simulation Features ⭐

### Real-Time Updates Every Second:
- 🚗 **Vehicle Movement Tracking** - See vehicles moving between roads
- 📊 **Live Traffic Dashboard** - Real-time congestion levels with visual indicators
- 🔄 **Dynamic Traffic Conditions** - Traffic density changes automatically
- ⏱️ **Simulation Timer** - Track simulation progress in real-time
- 📈 **Final Statistics** - Comprehensive analysis at simulation end

## Classes Description

### TrafficManagementSystem
Main controller that coordinates all traffic management operations.

### TrafficSignal
Manages individual traffic signals with:
- Automatic state transitions (RED → GREEN → YELLOW → RED)
- Configurable timing
- Start/stop functionality

### Road
Represents a road segment with:
- Capacity management
- Congestion level calculation
- Speed limit enforcement
- Connected road mapping

### Vehicle
Represents vehicles in the system with:
- Type classification
- Current location tracking
- Destination management
- Priority levels

### CongestionMonitor
Monitors traffic and generates alerts for:
- High congestion areas
- Road utilization percentage
- Real-time recommendations

### RouteOptimizer
Calculates optimal routes using:
- Dijkstra's shortest path algorithm
- Real-time traffic data
- Travel time estimation

## How to Run

### Compile all Java files:
```bash
javac *.java
```

### Choose your simulation:

#### 1. Quick 4-Road Live Simulation (20 seconds):
```bash
java QuickSimulation4Roads
```

#### 2. Enhanced 8-Road Live Simulation (30 seconds):
```bash
java EnhancedTrafficDemo
```

#### 3. Basic Demo (Original):
```bash
java TrafficSimulationDemo
```

## Sample Output - Live Simulation

```
╔══════════════════════════════════════════════════════════════╗
║     🚦 URBAN TRAFFIC MANAGEMENT SYSTEM 🚦                   ║
║     Enhanced Live Simulation - 8 Road Network               ║
╚══════════════════════════════════════════════════════════════╝

🏗️  Setting up 8-road urban network...
✓ 8-road network established with varying traffic conditions

╔════════════════════════════════════════════════════════╗
║        LIVE TRAFFIC SIMULATION STARTED                ║
║        Duration: 30 seconds                           ║
╚════════════════════════════════════════════════════════╝

🚗 Vehicle Movement Update:
   V001 (CAR) moved to Downtown Boulevard @ 52.5 km/h
   V009 (EMERGENCY) moved to Central Street @ 42.0 km/h

📊 Real-Time Traffic Status:
┌─────────────────────────────┬──────────┬─────────────┬────────────┐
│ Road Name                   │ Vehicles │ Congestion  │ Avg Speed  │
├─────────────────────────────┼──────────┼─────────────┼────────────┤
│ Downtown Boulevard          │ 120/150  │ HIGH 🟠     │ 52 km/h    │
│ North Highway               │ 180/200  │ SEVERE 🔴   │ 20 km/h    │
│ South Expressway            │  95/180  │ MODERATE 🟡 │ 56 km/h    │
│ East Parkway               │  65/120  │ MODERATE 🟡 │ 48 km/h    │
│ West Avenue                 │  85/140  │ MODERATE 🟡 │ 45 km/h    │
│ Central Street              │ 140/160  │ HIGH 🟠     │ 35 km/h    │
│ Park Road                   │  30/100  │ LOW 🟢      │ 50 km/h    │
│ Harbor Drive                │  75/130  │ MODERATE 🟡 │ 41 km/h    │
└─────────────────────────────┴──────────┴─────────────┴────────────┘

⚠️  CONGESTION ALERT ⚠️
Road: North Highway (R002)
Level: SEVERE
Vehicles: 180/200
Utilization: 90.0%
Recommendation: Consider alternate routes. Expect significant delays.

⏱️  Simulation Time: 15s

📈 Final Traffic Statistics:
   Total Roads Monitored: 8
   Total Vehicles: 790
   Congested Roads: 2
   Average Road Utilization: 64.3%
   Simulation Duration: 30 seconds
```

## Key Algorithms

### 1. Signal Timing Algorithm
- Uses Timer-based scheduling for automatic state transitions
- Respects yellow light duration (3 seconds)
- Supports dynamic timing adjustments

### 2. Congestion Detection
- Calculates road utilization: `utilization = currentVehicles / capacity`
- Classifies congestion levels based on thresholds:
  - LOW: < 30%
  - MODERATE: 30-60%
  - HIGH: 60-85%
  - SEVERE: > 85%

### 3. Route Optimization (Dijkstra's Algorithm)
- Creates weighted graph based on estimated travel times
- Considers congestion in weight calculation
- Finds shortest path based on time, not distance

## Configuration Options

### Signal Timing
- Green duration: 20-40 seconds (default: 30s)
- Red duration: 20-35 seconds (default: 25s)
- Yellow duration: 3 seconds (fixed)

### Road Parameters
- Capacity: 80-120 vehicles
- Speed limits: 50-70 km/h
- Length: 1.8-3.0 km

## Future Enhancements

1. **Machine Learning Integration**
   - Predictive congestion analysis
   - Adaptive signal timing based on patterns

2. **Real-time Data Integration**
   - GPS tracking
   - Weather conditions
   - Accident detection

3. **Multi-modal Transportation**
   - Public transit integration
   - Pedestrian crossing management
   - Bike lane consideration

4. **Advanced Visualization**
   - GUI interface with map view
   - Real-time traffic heat maps
   - Historical data analytics

5. **Emergency Response**
   - Priority lanes for emergency vehicles
   - Automatic signal override
   - Fastest emergency route calculation

## Technical Requirements

- Java 8 or higher
- No external dependencies required
- Works on Windows, Linux, and macOS

## License
Educational project for traffic management simulation.

## Author
Created as a demonstration of urban traffic management concepts.

---
*This system demonstrates core concepts of intelligent transportation systems (ITS) and can be extended for real-world applications.*
