import java.util.*;

/**
 * Enhanced Traffic Simulation Demo with Live 8-Road Network
 */
public class EnhancedTrafficDemo {
    
    public static void main(String[] args) {
        displayWelcomeBanner();
        
        // Initialize the traffic management system
        TrafficManagementSystem tms = new TrafficManagementSystem();
        
        // Setup 8-road city network
        setup8RoadNetwork(tms);
        
        // Add multiple vehicles
        addMultipleVehicles(tms);
        
        // Start traffic signals
        tms.startSimulation();
        
        // Wait for signals to initialize
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Start live simulation
        LiveTrafficSimulator simulator = new LiveTrafficSimulator(tms);
        simulator.startLiveSimulation(30); // 30 seconds simulation
        
        // Wait for simulation to complete
        try {
            Thread.sleep(32000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Demonstrate advanced features
        demonstrateAdvancedFeatures(simulator.getTrafficManagementSystem());
        
        displayCompletionBanner();
    }
    
    private static void displayWelcomeBanner() {
        System.out.println("╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║                                                              ║");
        System.out.println("║     🚦 URBAN TRAFFIC MANAGEMENT SYSTEM 🚦                   ║");
        System.out.println("║     Enhanced Live Simulation - 8 Road Network               ║");
        System.out.println("║     Version 2.0 - October 2025                              ║");
        System.out.println("║                                                              ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝\n");
    }
    
    private static void setup8RoadNetwork(TrafficManagementSystem tms) {
        System.out.println("🏗️  Setting up 8-road urban network...\n");
        
        // Create 8 traffic signals at major intersections
        TrafficSignal[] signals = {
            new TrafficSignal("Downtown Center", 35, 25),
            new TrafficSignal("North Junction", 30, 30),
            new TrafficSignal("South Plaza", 25, 35),
            new TrafficSignal("East Gate", 28, 27),
            new TrafficSignal("West Terminal", 32, 28),
            new TrafficSignal("Central Square", 30, 25),
            new TrafficSignal("Park Avenue Cross", 27, 28),
            new TrafficSignal("Harbor Bridge", 33, 27)
        };
        
        String[] signalLocations = {
            "S1-Downtown", "S2-North", "S3-South", "S4-East",
            "S5-West", "S6-Central", "S7-Park", "S8-Harbor"
        };
        
        for (int i = 0; i < signals.length; i++) {
            tms.addSignal(signalLocations[i], signals[i]);
        }
        
        System.out.println();
        
        // Create 8 major roads with different characteristics
        Road[] roads = {
            new Road("R001", "Downtown Boulevard", 150, 4.5, 70),
            new Road("R002", "North Highway", 200, 6.0, 80),
            new Road("R003", "South Expressway", 180, 5.2, 75),
            new Road("R004", "East Parkway", 120, 3.8, 65),
            new Road("R005", "West Avenue", 140, 4.0, 60),
            new Road("R006", "Central Street", 160, 4.2, 70),
            new Road("R007", "Park Road", 100, 2.5, 50),
            new Road("R008", "Harbor Drive", 130, 3.5, 55)
        };
        
        // Set up realistic road connections for a city grid
        roads[0].addConnectedRoad("R002"); // Downtown -> North
        roads[0].addConnectedRoad("R003"); // Downtown -> South
        roads[0].addConnectedRoad("R006"); // Downtown -> Central
        
        roads[1].addConnectedRoad("R004"); // North -> East
        roads[1].addConnectedRoad("R005"); // North -> West
        roads[1].addConnectedRoad("R000"); // North -> Downtown
        
        roads[2].addConnectedRoad("R007"); // South -> Park
        roads[2].addConnectedRoad("R008"); // South -> Harbor
        roads[2].addConnectedRoad("R000"); // South -> Downtown
        
        roads[3].addConnectedRoad("R001"); // East -> North
        roads[3].addConnectedRoad("R006"); // East -> Central
        
        roads[4].addConnectedRoad("R001"); // West -> North
        roads[4].addConnectedRoad("R006"); // West -> Central
        
        roads[5].addConnectedRoad("R000"); // Central -> Downtown
        roads[5].addConnectedRoad("R003"); // Central -> East
        roads[5].addConnectedRoad("R004"); // Central -> West
        
        roads[6].addConnectedRoad("R002"); // Park -> South
        roads[6].addConnectedRoad("R007"); // Park -> Harbor
        
        roads[7].addConnectedRoad("R002"); // Harbor -> South
        roads[7].addConnectedRoad("R006"); // Harbor -> Park
        
        for (Road road : roads) {
            tms.addRoad(road.getRoadId(), road);
        }
        
        // Set initial traffic conditions with variety
        roads[0].setVehicleCount(120);  // Heavy - Downtown
        roads[1].setVehicleCount(180);  // Severe - North Highway
        roads[2].setVehicleCount(95);   // Moderate - South Expressway
        roads[3].setVehicleCount(65);   // Moderate - East Parkway
        roads[4].setVehicleCount(85);   // Moderate - West Avenue
        roads[5].setVehicleCount(140);  // High - Central Street
        roads[6].setVehicleCount(30);   // Low - Park Road
        roads[7].setVehicleCount(75);   // Moderate - Harbor Drive
        
        System.out.println("\n✓ 8-road network established with varying traffic conditions");
    }
    
    private static void addMultipleVehicles(TrafficManagementSystem tms) {
        System.out.println("\n🚗 Adding diverse vehicle fleet...\n");
        
        // Create 15 vehicles of different types
        Vehicle[] vehicles = {
            new Vehicle("V001", Vehicle.VehicleType.CAR, "S1-Downtown"),
            new Vehicle("V002", Vehicle.VehicleType.CAR, "S2-North"),
            new Vehicle("V003", Vehicle.VehicleType.BUS, "S3-South"),
            new Vehicle("V004", Vehicle.VehicleType.BUS, "S4-East"),
            new Vehicle("V005", Vehicle.VehicleType.TRUCK, "S5-West"),
            new Vehicle("V006", Vehicle.VehicleType.TRUCK, "S6-Central"),
            new Vehicle("V007", Vehicle.VehicleType.CAR, "S7-Park"),
            new Vehicle("V008", Vehicle.VehicleType.MOTORCYCLE, "S8-Harbor"),
            new Vehicle("V009", Vehicle.VehicleType.EMERGENCY, "S1-Downtown"),
            new Vehicle("V010", Vehicle.VehicleType.CAR, "S2-North"),
            new Vehicle("V011", Vehicle.VehicleType.BUS, "S3-South"),
            new Vehicle("V012", Vehicle.VehicleType.CAR, "S4-East"),
            new Vehicle("V013", Vehicle.VehicleType.MOTORCYCLE, "S5-West"),
            new Vehicle("V014", Vehicle.VehicleType.TRUCK, "S6-Central"),
            new Vehicle("V015", Vehicle.VehicleType.EMERGENCY, "S7-Park")
        };
        
        String[] destinations = {
            "S8-Harbor", "S5-West", "S6-Central", "S1-Downtown",
            "S2-North", "S7-Park", "S3-South", "S4-East",
            "S6-Central", "S8-Harbor", "S1-Downtown", "S7-Park",
            "S2-North", "S5-West", "S4-East"
        };
        
        for (int i = 0; i < vehicles.length; i++) {
            vehicles[i].setDestination(destinations[i]);
            tms.addVehicle(vehicles[i]);
        }
        
        System.out.println("✓ Added " + vehicles.length + " vehicles:");
        System.out.println("   - Cars: 6");
        System.out.println("   - Buses: 3");
        System.out.println("   - Trucks: 3");
        System.out.println("   - Motorcycles: 2");
        System.out.println("   - Emergency Vehicles: 2");
    }
    
    private static void demonstrateAdvancedFeatures(TrafficManagementSystem tms) {
        System.out.println("\n\n╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║           ADVANCED FEATURES DEMONSTRATION                    ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝");
        
        // Feature 1: Multiple Route Optimization
        System.out.println("\n🗺️  FEATURE 1: Multi-Route Optimization");
        System.out.println("═══════════════════════════════════════════════");
        
        String[][] routes = {
            {"R001", "R006"},
            {"R002", "R008"},
            {"R005", "R003"}
        };
        
        for (String[] route : routes) {
            tms.findOptimalRoute(route[0], route[1]);
            System.out.println();
        }
        
        // Feature 2: Intelligent Signal Adjustment
        System.out.println("\n⚙️  FEATURE 2: Intelligent Signal Timing Adjustment");
        System.out.println("═══════════════════════════════════════════════════");
        System.out.println("Analyzing traffic patterns and adjusting signals...\n");
        
        Map<String, Road> roads = tms.getRoads();
        Map<String, TrafficSignal> signals = tms.getSignals();
        
        // Adjust signals based on congestion
        for (Map.Entry<String, Road> entry : roads.entrySet()) {
            Road road = entry.getValue();
            if (road.getCongestionLevel() == Road.CongestionLevel.HIGH || 
                road.getCongestionLevel() == Road.CongestionLevel.SEVERE) {
                
                // Find corresponding signal and increase green time
                String signalKey = findSignalForRoad(entry.getKey());
                if (signalKey != null && signals.containsKey(signalKey)) {
                    tms.adjustSignalTiming(signalKey, 40, 20);
                }
            }
        }
        
        // Feature 3: Traffic Statistics
        displayTrafficStatistics(tms);
        
        // Feature 4: Emergency Vehicle Priority
        System.out.println("\n🚨 FEATURE 4: Emergency Vehicle Priority System");
        System.out.println("═════════════════════════════════════════════════");
        
        List<Vehicle> emergencyVehicles = new ArrayList<>();
        for (Vehicle v : tms.getVehicles()) {
            if (v.isEmergencyVehicle()) {
                emergencyVehicles.add(v);
            }
        }
        
        System.out.println("Emergency vehicles detected: " + emergencyVehicles.size());
        for (Vehicle ev : emergencyVehicles) {
            System.out.println("   ⚡ " + ev.getVehicleId() + " - Priority Level: " + ev.getPriority());
            System.out.println("      Current: " + ev.getCurrentLocation() + 
                             " → Destination: " + ev.getDestination());
        }
    }
    
    private static String findSignalForRoad(String roadId) {
        // Map roads to signals (simplified mapping)
        Map<String, String> roadToSignal = new HashMap<>();
        roadToSignal.put("R001", "S1-Downtown");
        roadToSignal.put("R002", "S2-North");
        roadToSignal.put("R003", "S3-South");
        roadToSignal.put("R004", "S4-East");
        roadToSignal.put("R005", "S5-West");
        roadToSignal.put("R006", "S6-Central");
        roadToSignal.put("R007", "S7-Park");
        roadToSignal.put("R008", "S8-Harbor");
        
        return roadToSignal.get(roadId);
    }
    
    private static void displayTrafficStatistics(TrafficManagementSystem tms) {
        System.out.println("\n📊 FEATURE 3: Comprehensive Traffic Statistics");
        System.out.println("═════════════════════════════════════════════════");
        
        Map<String, Road> roads = tms.getRoads();
        
        int totalCapacity = 0;
        int totalVehicles = 0;
        double totalDistance = 0;
        int lowCongestion = 0, moderateCongestion = 0, highCongestion = 0, severeCongestion = 0;
        
        for (Road road : roads.values()) {
            totalCapacity += road.getCapacity();
            totalVehicles += road.getVehicleCount();
            totalDistance += road.getLength();
            
            switch (road.getCongestionLevel()) {
                case LOW:
                    lowCongestion++;
                    break;
                case MODERATE:
                    moderateCongestion++;
                    break;
                case HIGH:
                    highCongestion++;
                    break;
                case SEVERE:
                    severeCongestion++;
                    break;
            }
        }
        
        System.out.println("\nNetwork Statistics:");
        System.out.println("   Total Road Network: " + String.format("%.1f", totalDistance) + " km");
        System.out.println("   Total Capacity: " + totalCapacity + " vehicles");
        System.out.println("   Current Vehicles: " + totalVehicles + " vehicles");
        System.out.println("   Network Utilization: " + 
                         String.format("%.1f%%", (totalVehicles * 100.0 / totalCapacity)));
        
        System.out.println("\nCongestion Distribution:");
        System.out.println("   🟢 Low: " + lowCongestion + " roads");
        System.out.println("   🟡 Moderate: " + moderateCongestion + " roads");
        System.out.println("   🟠 High: " + highCongestion + " roads");
        System.out.println("   🔴 Severe: " + severeCongestion + " roads");
        
        System.out.println("\nSignal System:");
        System.out.println("   Active Signals: " + tms.getSignals().size());
        System.out.println("   Total Intersections Monitored: " + tms.getSignals().size());
    }
    
    private static void displayCompletionBanner() {
        System.out.println("\n\n╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║                                                              ║");
        System.out.println("║              SIMULATION COMPLETED SUCCESSFULLY               ║");
        System.out.println("║                                                              ║");
        System.out.println("║  All traffic management features demonstrated:              ║");
        System.out.println("║  ✓ Live 8-road network simulation                           ║");
        System.out.println("║  ✓ Real-time congestion monitoring                          ║");
        System.out.println("║  ✓ Dynamic traffic signal control                           ║");
        System.out.println("║  ✓ Intelligent route optimization                           ║");
        System.out.println("║  ✓ Emergency vehicle priority                               ║");
        System.out.println("║  ✓ Comprehensive traffic analytics                          ║");
        System.out.println("║                                                              ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝");
    }
}
