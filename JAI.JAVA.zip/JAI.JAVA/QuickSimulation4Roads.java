/**
 * Quick 4-Road Simulation Demo
 * A simplified version for quick demonstrations
 */
public class QuickSimulation4Roads {
    
    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════════════════╗");
        System.out.println("║     QUICK 4-ROAD TRAFFIC SIMULATION                 ║");
        System.out.println("║     Live Demo - October 2025                        ║");
        System.out.println("╚══════════════════════════════════════════════════════╝\n");
        
        // Initialize system
        TrafficManagementSystem tms = new TrafficManagementSystem();
        
        // Setup 4-road network
        setup4RoadNetwork(tms);
        
        // Add vehicles
        addVehicles(tms);
        
        // Start simulation
        tms.startSimulation();
        
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Live simulation for 20 seconds
        LiveTrafficSimulator simulator = new LiveTrafficSimulator(tms);
        simulator.startLiveSimulation(20);
        
        // Wait for completion
        try {
            Thread.sleep(22000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        // Show route optimization
        System.out.println("\n\n🗺️  Route Optimization Examples:");
        System.out.println("════════════════════════════════════════");
        tms.findOptimalRoute("R001", "R004");
        System.out.println();
        tms.findOptimalRoute("R002", "R003");
        
        System.out.println("\n\n✓ 4-Road Simulation Complete!");
    }
    
    private static void setup4RoadNetwork(TrafficManagementSystem tms) {
        System.out.println("🏗️  Setting up 4-road network...\n");
        
        // 4 Traffic Signals
        tms.addSignal("Intersection-1", new TrafficSignal("North-South Cross", 30, 25));
        tms.addSignal("Intersection-2", new TrafficSignal("East-West Cross", 28, 27));
        tms.addSignal("Intersection-3", new TrafficSignal("Main Junction", 32, 28));
        tms.addSignal("Intersection-4", new TrafficSignal("Central Hub", 25, 30));
        
        System.out.println();
        
        // 4 Main Roads
        Road road1 = new Road("R001", "Main Street", 100, 3.0, 60);
        Road road2 = new Road("R002", "Second Avenue", 120, 3.5, 65);
        Road road3 = new Road("R003", "Third Boulevard", 90, 2.5, 55);
        Road road4 = new Road("R004", "Fourth Highway", 110, 4.0, 70);
        
        // Connect roads
        road1.addConnectedRoad("R002");
        road1.addConnectedRoad("R003");
        
        road2.addConnectedRoad("R003");
        road2.addConnectedRoad("R004");
        
        road3.addConnectedRoad("R001");
        road3.addConnectedRoad("R004");
        
        road4.addConnectedRoad("R002");
        road4.addConnectedRoad("R001");
        
        tms.addRoad("R001", road1);
        tms.addRoad("R002", road2);
        tms.addRoad("R003", road3);
        tms.addRoad("R004", road4);
        
        // Set initial traffic
        road1.setVehicleCount(75);  // High
        road2.setVehicleCount(50);  // Moderate
        road3.setVehicleCount(85);  // Severe
        road4.setVehicleCount(40);  // Low
        
        System.out.println("\n✓ 4-road network ready\n");
    }
    
    private static void addVehicles(TrafficManagementSystem tms) {
        System.out.println("🚗 Adding vehicles...\n");
        
        Vehicle[] vehicles = {
            new Vehicle("V001", Vehicle.VehicleType.CAR, "Intersection-1"),
            new Vehicle("V002", Vehicle.VehicleType.BUS, "Intersection-2"),
            new Vehicle("V003", Vehicle.VehicleType.TRUCK, "Intersection-3"),
            new Vehicle("V004", Vehicle.VehicleType.EMERGENCY, "Intersection-4"),
            new Vehicle("V005", Vehicle.VehicleType.CAR, "Intersection-1"),
            new Vehicle("V006", Vehicle.VehicleType.MOTORCYCLE, "Intersection-2")
        };
        
        for (Vehicle v : vehicles) {
            tms.addVehicle(v);
        }
        
        System.out.println("✓ Added " + vehicles.length + " vehicles\n");
    }
}
