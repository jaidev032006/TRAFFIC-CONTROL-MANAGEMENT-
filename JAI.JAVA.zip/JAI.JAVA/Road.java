import java.util.*;

/**
 * Road class representing a street or highway segment
 */
public class Road {
    private String roadId;
    private String name;
    private int capacity;
    private int currentVehicles;
    private double length; // in kilometers
    private int speedLimit; // in km/h
    private List<String> connectedRoads;
    
    public enum CongestionLevel {
        LOW, MODERATE, HIGH, SEVERE
    }
    
    public Road(String roadId, String name, int capacity, double length, int speedLimit) {
        this.roadId = roadId;
        this.name = name;
        this.capacity = capacity;
        this.currentVehicles = 0;
        this.length = length;
        this.speedLimit = speedLimit;
        this.connectedRoads = new ArrayList<>();
    }
    
    public void addVehicle() {
        if (currentVehicles < capacity) {
            currentVehicles++;
        }
    }
    
    public void removeVehicle() {
        if (currentVehicles > 0) {
            currentVehicles--;
        }
    }
    
    public void addConnectedRoad(String roadId) {
        connectedRoads.add(roadId);
    }
    
    public CongestionLevel getCongestionLevel() {
        double utilization = (double) currentVehicles / capacity;
        
        if (utilization < 0.3) {
            return CongestionLevel.LOW;
        } else if (utilization < 0.6) {
            return CongestionLevel.MODERATE;
        } else if (utilization < 0.85) {
            return CongestionLevel.HIGH;
        } else {
            return CongestionLevel.SEVERE;
        }
    }
    
    public double getAverageSpeed() {
        double utilization = (double) currentVehicles / capacity;
        
        // Speed decreases with congestion
        if (utilization < 0.3) {
            return speedLimit;
        } else if (utilization < 0.6) {
            return speedLimit * 0.75;
        } else if (utilization < 0.85) {
            return speedLimit * 0.5;
        } else {
            return speedLimit * 0.25;
        }
    }
    
    public double getEstimatedTravelTime() {
        // Travel time in minutes
        return (length / getAverageSpeed()) * 60;
    }
    
    public boolean isCongested() {
        return getCongestionLevel() == CongestionLevel.HIGH || 
               getCongestionLevel() == CongestionLevel.SEVERE;
    }
    
    // Getters
    public String getRoadId() {
        return roadId;
    }
    
    public String getName() {
        return name;
    }
    
    public int getCapacity() {
        return capacity;
    }
    
    public int getVehicleCount() {
        return currentVehicles;
    }
    
    public double getLength() {
        return length;
    }
    
    public int getSpeedLimit() {
        return speedLimit;
    }
    
    public List<String> getConnectedRoads() {
        return connectedRoads;
    }
    
    public void setVehicleCount(int count) {
        this.currentVehicles = Math.min(count, capacity);
    }
}
