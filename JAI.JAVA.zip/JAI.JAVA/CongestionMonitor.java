import java.util.*;

/**
 * Congestion Monitor to detect and alert about traffic congestion
 */
public class CongestionMonitor {
    private Map<String, List<CongestionAlert>> alerts;
    private static final double CONGESTION_THRESHOLD = 0.75;
    
    public CongestionMonitor() {
        this.alerts = new HashMap<>();
    }
    
    public void startMonitoring(Map<String, Road> roads, List<Vehicle> vehicles) {
        System.out.println("\n=== Congestion Monitoring Started ===");
        
        for (Map.Entry<String, Road> entry : roads.entrySet()) {
            Road road = entry.getValue();
            checkCongestion(road);
        }
    }
    
    public void checkCongestion(Road road) {
        Road.CongestionLevel level = road.getCongestionLevel();
        
        if (level == Road.CongestionLevel.HIGH || level == Road.CongestionLevel.SEVERE) {
            CongestionAlert alert = new CongestionAlert(
                road.getRoadId(),
                road.getName(),
                level,
                road.getVehicleCount(),
                road.getCapacity(),
                new Date()
            );
            
            addAlert(road.getRoadId(), alert);
            displayAlert(alert);
        }
    }
    
    private void addAlert(String roadId, CongestionAlert alert) {
        if (!alerts.containsKey(roadId)) {
            alerts.put(roadId, new ArrayList<>());
        }
        alerts.get(roadId).add(alert);
    }
    
    private void displayAlert(CongestionAlert alert) {
        System.out.println("\n⚠️  CONGESTION ALERT ⚠️");
        System.out.println("Road: " + alert.getRoadName() + " (" + alert.getRoadId() + ")");
        System.out.println("Level: " + alert.getLevel());
        System.out.println("Vehicles: " + alert.getVehicleCount() + "/" + alert.getCapacity());
        System.out.println("Utilization: " + String.format("%.1f%%", alert.getUtilization() * 100));
        System.out.println("Time: " + alert.getTimestamp());
        System.out.println("Recommendation: " + getRecommendation(alert));
    }
    
    private String getRecommendation(CongestionAlert alert) {
        if (alert.getLevel() == Road.CongestionLevel.SEVERE) {
            return "Consider alternate routes. Expect significant delays.";
        } else if (alert.getLevel() == Road.CongestionLevel.HIGH) {
            return "Heavy traffic detected. Plan for moderate delays.";
        } else {
            return "Monitor traffic conditions.";
        }
    }
    
    public Map<String, List<CongestionAlert>> getAlerts() {
        return alerts;
    }
    
    public List<CongestionAlert> getAlertsByRoad(String roadId) {
        return alerts.getOrDefault(roadId, new ArrayList<>());
    }
    
    public void clearAlerts() {
        alerts.clear();
    }
    
    /**
     * Inner class for Congestion Alerts
     */
    public static class CongestionAlert {
        private String roadId;
        private String roadName;
        private Road.CongestionLevel level;
        private int vehicleCount;
        private int capacity;
        private Date timestamp;
        
        public CongestionAlert(String roadId, String roadName, Road.CongestionLevel level,
                             int vehicleCount, int capacity, Date timestamp) {
            this.roadId = roadId;
            this.roadName = roadName;
            this.level = level;
            this.vehicleCount = vehicleCount;
            this.capacity = capacity;
            this.timestamp = timestamp;
        }
        
        public double getUtilization() {
            return (double) vehicleCount / capacity;
        }
        
        public String getRoadId() {
            return roadId;
        }
        
        public String getRoadName() {
            return roadName;
        }
        
        public Road.CongestionLevel getLevel() {
            return level;
        }
        
        public int getVehicleCount() {
            return vehicleCount;
        }
        
        public int getCapacity() {
            return capacity;
        }
        
        public Date getTimestamp() {
            return timestamp;
        }
    }
}
