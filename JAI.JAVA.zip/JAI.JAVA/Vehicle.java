/**
 * Vehicle class representing different types of vehicles in the system
 */
public class Vehicle {
    private String vehicleId;
    private VehicleType type;
    private String currentLocation;
    private String destination;
    private double speed;
    private String currentRoad;
    
    public enum VehicleType {
        CAR, BUS, TRUCK, MOTORCYCLE, EMERGENCY
    }
    
    public Vehicle(String vehicleId, VehicleType type, String startLocation) {
        this.vehicleId = vehicleId;
        this.type = type;
        this.currentLocation = startLocation;
        this.speed = 0;
    }
    
    public void setDestination(String destination) {
        this.destination = destination;
    }
    
    public void move(String newLocation, String roadId) {
        this.currentLocation = newLocation;
        this.currentRoad = roadId;
    }
    
    public void setSpeed(double speed) {
        this.speed = speed;
    }
    
    public boolean isEmergencyVehicle() {
        return type == VehicleType.EMERGENCY;
    }
    
    public int getPriority() {
        switch (type) {
            case EMERGENCY:
                return 5;
            case BUS:
                return 3;
            case TRUCK:
                return 2;
            case CAR:
            case MOTORCYCLE:
            default:
                return 1;
        }
    }
    
    // Getters
    public String getVehicleId() {
        return vehicleId;
    }
    
    public VehicleType getType() {
        return type;
    }
    
    public String getCurrentLocation() {
        return currentLocation;
    }
    
    public String getDestination() {
        return destination;
    }
    
    public double getSpeed() {
        return speed;
    }
    
    public String getCurrentRoad() {
        return currentRoad;
    }
    
    @Override
    public String toString() {
        return "Vehicle[" + vehicleId + ", Type: " + type + ", Location: " + currentLocation + "]";
    }
}
