import java.util.Timer;
import java.util.TimerTask;

/**
 * Traffic Signal class to manage signal timing and states
 */
public class TrafficSignal {
    private String location;
    private SignalState currentState;
    private int greenDuration;  // in seconds
    private int redDuration;    // in seconds
    private int yellowDuration; // in seconds
    private Timer timer;
    private boolean isRunning;
    
    public enum SignalState {
        RED, YELLOW, GREEN
    }
    
    public TrafficSignal(String location, int greenDuration, int redDuration) {
        this.location = location;
        this.greenDuration = greenDuration;
        this.redDuration = redDuration;
        this.yellowDuration = 3; // Standard 3 seconds
        this.currentState = SignalState.RED;
        this.timer = new Timer();
        this.isRunning = false;
    }
    
    public void start() {
        if (!isRunning) {
            isRunning = true;
            scheduleNextState();
            System.out.println("Traffic signal started at: " + location);
        }
    }
    
    public void stop() {
        if (isRunning) {
            timer.cancel();
            isRunning = false;
            System.out.println("Traffic signal stopped at: " + location);
        }
    }
    
    private void scheduleNextState() {
        int delay = 0;
        SignalState nextState = null;
        
        switch (currentState) {
            case RED:
                nextState = SignalState.GREEN;
                delay = redDuration * 1000;
                break;
            case GREEN:
                nextState = SignalState.YELLOW;
                delay = greenDuration * 1000;
                break;
            case YELLOW:
                nextState = SignalState.RED;
                delay = yellowDuration * 1000;
                break;
        }
        
        final SignalState stateToSet = nextState;
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                currentState = stateToSet;
                System.out.println("[" + location + "] Signal changed to: " + currentState);
                if (isRunning) {
                    scheduleNextState();
                }
            }
        }, delay);
    }
    
    public void adjustTiming(int newGreenDuration, int newRedDuration) {
        this.greenDuration = newGreenDuration;
        this.redDuration = newRedDuration;
        System.out.println("Timing adjusted for " + location + 
                         " - Green: " + greenDuration + "s, Red: " + redDuration + "s");
    }
    
    public SignalState getCurrentState() {
        return currentState;
    }
    
    public String getLocation() {
        return location;
    }
    
    public int getGreenDuration() {
        return greenDuration;
    }
    
    public int getRedDuration() {
        return redDuration;
    }
    
    public boolean isGreen() {
        return currentState == SignalState.GREEN;
    }
    
    public boolean isRed() {
        return currentState == SignalState.RED;
    }
}
