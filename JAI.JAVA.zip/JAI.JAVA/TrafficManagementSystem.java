import java.util.*;

/**
 * Main Traffic Management System
 * Coordinates all traffic management operations
 */
public class TrafficManagementSystem {
    private Map<String, TrafficSignal> signals;
    private Map<String, Road> roads;
    private List<Vehicle> vehicles;
    private CongestionMonitor congestionMonitor;
    private RouteOptimizer routeOptimizer;
    
    public TrafficManagementSystem() {
        this.signals = new LinkedHashMap<>();
        this.roads = new LinkedHashMap<>();
        this.vehicles = new ArrayList<>();
        this.congestionMonitor = new CongestionMonitor();
        this.routeOptimizer = new RouteOptimizer();
    }
    
    public void addSignal(String location, TrafficSignal signal) {
        signals.put(location, signal);
        System.out.println("Traffic signal added at: " + location);
    }
    
    public void addRoad(String roadId, Road road) {
        roads.put(roadId, road);
        System.out.println("Road added: " + roadId);
    }
    
    public void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    
    public void startSimulation() {
        System.out.println("\n=== Traffic Management System Started ===\n");
        
        // Start all traffic signals
        for (Map.Entry<String, TrafficSignal> entry : signals.entrySet()) {
            entry.getValue().start();
        }
        
        // Monitor congestion
        congestionMonitor.startMonitoring(roads, vehicles);
        
        // Display system status
        displaySystemStatus();
    }
    
    public void displaySystemStatus() {
        System.out.println("\n--- System Status ---");
        System.out.println("Active Signals: " + signals.size());
        System.out.println("Monitored Roads: " + roads.size());
        System.out.println("Active Vehicles: " + vehicles.size());
        
        System.out.println("\n--- Signal Status ---");
        for (Map.Entry<String, TrafficSignal> entry : signals.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue().getCurrentState());
        }
        
        System.out.println("\n--- Road Congestion ---");
        for (Map.Entry<String, Road> entry : roads.entrySet()) {
            Road road = entry.getValue();
            System.out.println(entry.getKey() + ": " + road.getCongestionLevel() + 
                             " (Vehicles: " + road.getVehicleCount() + "/" + road.getCapacity() + ")");
        }
    }
    
    public String findOptimalRoute(String start, String destination) {
        return routeOptimizer.calculateOptimalRoute(start, destination, roads);
    }
    
    public void adjustSignalTiming(String location, int greenTime, int redTime) {
        TrafficSignal signal = signals.get(location);
        if (signal != null) {
            signal.adjustTiming(greenTime, redTime);
            System.out.println("Signal timing adjusted at: " + location);
        }
    }
    
    public Map<String, TrafficSignal> getSignals() {
        return signals;
    }
    
    public Map<String, Road> getRoads() {
        return roads;
    }
    
    public List<Vehicle> getVehicles() {
        return vehicles;
    }
    
    public CongestionMonitor getCongestionMonitor() {
        return congestionMonitor;
    }
    
    public RouteOptimizer getRouteOptimizer() {
        return routeOptimizer;
    }
}